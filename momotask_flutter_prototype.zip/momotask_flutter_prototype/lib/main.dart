import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'login_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp();

  runApp(const MomoTaskApp());
}

class MomoTaskApp extends StatelessWidget {
  const MomoTaskApp({super.key});

  @override
  Widget build(BuildContext context) {
    const pink = Color(0xFFE58EAD);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MOMOTASK',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: pink,
          brightness: Brightness.light,
          surface: const Color(0xFFFFF9FB),
        ),
        scaffoldBackgroundColor: const Color(0xFFFFF7FA),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFFFFF7FA),
          foregroundColor: Color(0xFF49343D),
          elevation: 0,
          centerTitle: false,
        ),
      ),
      home: const LoginScreen(),
    );
  }
}