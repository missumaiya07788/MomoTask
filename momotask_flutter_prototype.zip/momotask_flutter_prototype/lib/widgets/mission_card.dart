import 'package:flutter/material.dart';
import '../models/mission.dart';

class MissionCard extends StatelessWidget {
  const MissionCard({
    super.key,
    required this.mission,
    required this.adminMode,
    this.onSubmit,
  });

  final Mission mission;
  final bool adminMode;
  final VoidCallback? onSubmit;

  @override
  Widget build(BuildContext context) {
    final statusText = switch (mission.status) {
      MissionStatus.available => 'Ready to start',
      MissionStatus.submitted => 'Waiting for approval',
      MissionStatus.approved => 'Completed ✓',
    };
    final statusColor = switch (mission.status) {
      MissionStatus.available => const Color(0xFFB76B89),
      MissionStatus.submitted => const Color(0xFF9A78B5),
      MissionStatus.approved => const Color(0xFF57936B),
    };

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: const Color(0xFFFFEEF4), borderRadius: BorderRadius.circular(14)),
              child: const Icon(Icons.auto_awesome_rounded, color: Color(0xFFBC6D8D)),
            ),
            const SizedBox(width: 11),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(mission.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              Text('${mission.category} · ${mission.dueLabel}', style: const TextStyle(color: Colors.black54, fontSize: 12)),
            ])),
            Text('+${mission.points} XP', style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFB45E80))),
          ]),
          const SizedBox(height: 10),
          Text(mission.description, style: const TextStyle(color: Color(0xFF66545C))),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: Text(statusText, style: TextStyle(color: statusColor, fontWeight: FontWeight.w600, fontSize: 12))),
            if (!adminMode && mission.status == MissionStatus.available)
              FilledButton.tonal(onPressed: onSubmit, child: const Text('Submit mission')),
          ]),
        ]),
      ),
    );
  }
}
