import 'package:flutter/material.dart';
import '../models/mission.dart';
import '../widgets/mission_card.dart';

class AdminScreen extends StatelessWidget {
  const AdminScreen({
    super.key,
    required this.missions,
    required this.onAddMission,
    required this.onApprove,
    required this.onSwitchRole,
  });

  final List<Mission> missions;
  final ValueChanged<Mission> onAddMission;
  final ValueChanged<Mission> onApprove;
  final VoidCallback onSwitchRole;

  Future<void> _createMission(BuildContext context) async {
    final title = TextEditingController();
    final details = TextEditingController();
    final points = TextEditingController(text: '10');
    final formKey = GlobalKey<FormState>();

    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Create a mission ✨'),
        content: Form(
          key: formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: title,
                  decoration: const InputDecoration(labelText: 'Mission title'),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'Add a title' : null,
                ),
                TextFormField(
                  controller: details,
                  decoration: const InputDecoration(labelText: 'Instructions'),
                  maxLines: 2,
                ),
                TextFormField(
                  controller: points,
                  decoration: const InputDecoration(labelText: 'XP points'),
                  keyboardType: TextInputType.number,
                  validator: (v) => int.tryParse(v ?? '') == null ? 'Enter a number' : null,
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              if (formKey.currentState!.validate()) Navigator.pop(context, true);
            },
            child: const Text('Create'),
          ),
        ],
      ),
    );

    if (result == true) {
      onAddMission(Mission(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        title: title.text.trim(),
        description: details.text.trim().isEmpty ? 'Complete this study mission.' : details.text.trim(),
        points: int.parse(points.text),
        category: 'Custom',
        dueLabel: 'Today',
      ));
    }
    title.dispose();
    details.dispose();
    points.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pending = missions.where((m) => m.status == MissionStatus.submitted).toList();
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
        children: [
          Row(
            children: [
              const _Mascot(),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('MOMOTASK', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
                    Text('Admin studio · Sumaiya’s study world', style: TextStyle(color: Colors.black54)),
                  ],
                ),
              ),
              IconButton(
                tooltip: 'Switch to student preview',
                onPressed: onSwitchRole,
                icon: const Icon(Icons.swap_horiz_rounded),
              ),
            ],
          ),
          const SizedBox(height: 22),
          _WelcomePanel(
            title: 'Make today count! 🌷',
            subtitle: 'Create little missions, celebrate every step.',
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              const Expanded(child: Text('Mission board', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
              FilledButton.icon(
                onPressed: () => _createMission(context),
                icon: const Icon(Icons.add, size: 18),
                label: const Text('New mission'),
              ),
            ],
          ),
          const SizedBox(height: 10),
          if (missions.isEmpty)
            const Text('No missions yet. Create the first one!'),
          ...missions.map((m) => MissionCard(mission: m, adminMode: true)),
          const SizedBox(height: 18),
          const Text('Needs your approval', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          if (pending.isEmpty)
            const _EmptyNote(text: 'No submissions yet. Sumaiya’s completed missions will appear here.'),
          ...pending.map((m) => Card(
            child: ListTile(
              leading: const CircleAvatar(backgroundColor: Color(0xFFFFE8F0), child: Icon(Icons.task_alt, color: Color(0xFFB75E82))),
              title: Text(m.title),
              subtitle: Text('${m.points} XP · Submitted by Sumaiya'),
              trailing: FilledButton(
                onPressed: () => onApprove(m),
                child: const Text('Approve'),
              ),
            ),
          )),
          const SizedBox(height: 14),
          const _EmptyNote(text: 'Prototype mode: mission changes currently stay on this device. Online sync will be connected in the next development step.'),
        ],
      ),
    );
  }
}

class _Mascot extends StatelessWidget {
  const _Mascot();
  @override
  Widget build(BuildContext context) => Container(
    width: 54, height: 54,
    decoration: BoxDecoration(color: const Color(0xFFFFE5EF), borderRadius: BorderRadius.circular(18)),
    child: const Center(child: Text('🥟', style: TextStyle(fontSize: 30))),
  );
}

class _WelcomePanel extends StatelessWidget {
  const _WelcomePanel({required this.title, required this.subtitle});
  final String title;
  final String subtitle;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      gradient: const LinearGradient(colors: [Color(0xFFFFE5EF), Color(0xFFF0E9FF)]),
      borderRadius: BorderRadius.circular(24),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold, color: Color(0xFF633F51))),
      const SizedBox(height: 6),
      Text(subtitle, style: const TextStyle(color: Color(0xFF765B69))),
    ]),
  );
}

class _EmptyNote extends StatelessWidget {
  const _EmptyNote({required this.text});
  final String text;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: const Color(0xFFFFF0F5), borderRadius: BorderRadius.circular(16)),
    child: Text(text, style: const TextStyle(color: Color(0xFF795D6A))),
  );
}
