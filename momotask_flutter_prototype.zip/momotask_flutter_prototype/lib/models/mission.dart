enum MissionStatus { available, submitted, approved }

class Mission {
  Mission({
    required this.id,
    required this.title,
    required this.description,
    required this.points,
    required this.category,
    required this.dueLabel,
    this.status = MissionStatus.available,
    this.createdBy = 'admin',
  });

  final String id;
  final String title;
  final String description;
  final int points;
  final String category;
  final String dueLabel;
  MissionStatus status;
  final String createdBy;
}
