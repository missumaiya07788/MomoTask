import 'package:flutter/material.dart';
import '../models/mission.dart';

class MissionCard extends StatelessWidget {
  const MissionCard({super.key, required this.mission, required this.adminMode, this.onSubmit});
  final Mission mission;
  final bool adminMode;
  final VoidCallback? onSubmit;

  @override
  Widget build(BuildContext context) {
    final statusText = switch (mission.status) {
      MissionStatus.available => 'READY TO START',
      MissionStatus.submitted => 'WAITING FOR APPROVAL',
      MissionStatus.approved => 'COMPLETED',
    };
    final statusColor = switch (mission.status) {
      MissionStatus.available => const Color(0xFF7658F5),
      MissionStatus.submitted => const Color(0xFFC18B35),
      MissionStatus.approved => const Color(0xFF3A9B72),
    };
    final iconBg = switch (mission.status) {
      MissionStatus.available => const Color(0xFFECE8FF),
      MissionStatus.submitted => const Color(0xFFFFF1D9),
      MissionStatus.approved => const Color(0xFFE2F5ED),
    };
    return LayoutBuilder(builder: (context, constraints) {
      final compact = constraints.maxWidth < 340;
      final titleBlock = Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(mission.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFF17152D), fontWeight: FontWeight.w800, fontSize: 14, height: 1.25)),
        const SizedBox(height: 3),
        Text('${mission.category}  ·  ${mission.dueLabel}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFF89879B), fontSize: 10)),
      ]));
      final xpBadge = Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6), decoration: BoxDecoration(color: const Color(0xFFF4F1FF), borderRadius: BorderRadius.circular(30)), child: Text('+${mission.points} XP', style: const TextStyle(color: Color(0xFF7658F5), fontSize: 10, fontWeight: FontWeight.w900)));
      return Container(
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(19), border: Border.all(color: const Color(0xFFECEAF3)), boxShadow: [BoxShadow(color: const Color(0xFF17152D).withOpacity(.025), blurRadius: 12, offset: const Offset(0, 4))]),
        child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Container(width: 43, height: 43, decoration: BoxDecoration(color: iconBg, borderRadius: BorderRadius.circular(14)), child: Icon(Icons.auto_awesome_rounded, color: statusColor, size: 21)), const SizedBox(width: 11), titleBlock, if (!compact) ...[const SizedBox(width: 6), xpBadge]]),
          if (compact) Padding(padding: const EdgeInsets.only(left: 54, top: 8), child: xpBadge),
          if (mission.description.isNotEmpty) ...[const SizedBox(height: 11), Text(mission.description, maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFF66647A), fontSize: 12, height: 1.4))],
          const SizedBox(height: 12),
          Wrap(alignment: WrapAlignment.spaceBetween, crossAxisAlignment: WrapCrossAlignment.center, runSpacing: 9, spacing: 10, children: [
            Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6), decoration: BoxDecoration(color: iconBg, borderRadius: BorderRadius.circular(30)), child: Row(mainAxisSize: MainAxisSize.min, children: [Container(width: 6, height: 6, decoration: BoxDecoration(color: statusColor, shape: BoxShape.circle)), const SizedBox(width: 6), Text(statusText, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: statusColor, fontWeight: FontWeight.w800, fontSize: 9, letterSpacing: .35))])),
            if (!adminMode && mission.status == MissionStatus.available) FilledButton(onPressed: onSubmit, style: FilledButton.styleFrom(backgroundColor: const Color(0xFF7658F5), foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9), visualDensity: VisualDensity.compact, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: const Text('Submit task', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800))),
          ]),
        ])),
      );
    });
  }
}
