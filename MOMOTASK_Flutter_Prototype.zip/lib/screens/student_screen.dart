import 'package:flutter/material.dart';
import '../models/mission.dart';
import '../widgets/mission_card.dart';

class StudentScreen extends StatelessWidget {
  const StudentScreen({
    super.key,
    required this.missions,
    required this.xp,
    required this.onSubmit,
    required this.onSwitchRole,
    required this.onLogout,
  });

  final List<Mission> missions;
  final int xp;
  final ValueChanged<Mission> onSubmit;
  final VoidCallback onSwitchRole;
  final VoidCallback onLogout;

  @override
  Widget build(BuildContext context) {
    final completed = missions.where((m) => m.status == MissionStatus.approved).length;
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
        children: [
          Row(children: [
            Container(
              width: 52, height: 52,
              decoration: BoxDecoration(color: const Color(0xFFFFE5EF), borderRadius: BorderRadius.circular(18)),
              child: const Center(child: Text('🐱', style: TextStyle(fontSize: 29))),
            ),
            const SizedBox(width: 12),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Hi, Sumaiya! 💗', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
              Text('Your little study adventure starts here'),
            ])),
            IconButton(onPressed: onLogout, icon: const Icon(Icons.logout_rounded), tooltip: 'Logout'),
          ]),
          const SizedBox(height: 22),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFFFFE3ED), Color(0xFFEDE5FF)]),
              borderRadius: BorderRadius.circular(24),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('YOUR STUDY POWER', style: TextStyle(letterSpacing: 1.1, fontWeight: FontWeight.bold, color: Color(0xFF80566A))),
              const SizedBox(height: 8),
              Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text('$xp', style: const TextStyle(fontSize: 42, fontWeight: FontWeight.w900, color: Color(0xFF67475A))),
                const Padding(padding: EdgeInsets.only(bottom: 8, left: 7), child: Text('XP earned')),
                const Spacer(),
                const Text('🌟', style: TextStyle(fontSize: 34)),
              ]),
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: const LinearProgressIndicator(value: 0.45, minHeight: 9, backgroundColor: Colors.white70, color: Color(0xFFD77FA1)),
              ),
              const SizedBox(height: 6),
              const Text('Level 1 · Keep going, you’re doing great!', style: TextStyle(color: Color(0xFF765B69))),
            ]),
          ),
          const SizedBox(height: 20),
          Row(children: [
            const Expanded(child: Text('Today’s missions', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
            Text('$completed completed', style: const TextStyle(color: Colors.black54)),
          ]),
          const SizedBox(height: 10),
          ...missions.map((m) => MissionCard(
            mission: m,
            adminMode: false,
            onSubmit: m.status == MissionStatus.available ? () => onSubmit(m) : null,
          )),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: const Color(0xFFFFF0F5), borderRadius: BorderRadius.circular(18)),
            child: const Row(children: [
              Text('🍡', style: TextStyle(fontSize: 30)),
              SizedBox(width: 12),
              Expanded(child: Text('A little progress every day adds up to something amazing!', style: TextStyle(fontWeight: FontWeight.w600))),
            ]),
          ),
        ],
      ),
    );
  }
}
