import 'package:flutter/material.dart';
import '../models/mission.dart';
import '../widgets/mission_card.dart';

const _studentInk = Color(0xFF17152D);
const _studentMuted = Color(0xFF89879B);
const _studentPurple = Color(0xFF7658F5);
const _studentCanvas = Color(0xFFF6F5FB);

class StudentScreen extends StatelessWidget {
  const StudentScreen({super.key, required this.missions, required this.xp, required this.weeklyXp, required this.weeklyTasks, required this.onSubmit, required this.onSwitchRole, required this.onLogout});
  final List<Mission> missions;
  final int xp;
  final List<int> weeklyXp;
  final List<int> weeklyTasks;
  final ValueChanged<Mission> onSubmit;
  final VoidCallback onSwitchRole;
  final VoidCallback onLogout;

  @override
  Widget build(BuildContext context) {
    final completed = missions.where((m) => m.status == MissionStatus.approved).toList();
    final pending = missions.where((m) => m.status == MissionStatus.submitted).toList();
    final available = missions.where((m) => m.status == MissionStatus.available).toList();
    final nextMilestone = xp < 40 ? 40 : xp < 50 ? 50 : xp < 60 ? 60 : 100;
    final progress = (xp / nextMilestone).clamp(0.0, 1.0).toDouble();
    final medal = xp >= 60 ? 'GOLD' : xp >= 50 ? 'SILVER' : xp >= 40 ? 'BRONZE' : 'STARTER';
    return Scaffold(backgroundColor: _studentCanvas, body: SafeArea(child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 720), child: ListView(padding: const EdgeInsets.fromLTRB(18, 12, 18, 28), children: [
      Row(children: [Container(width: 48, height: 48, decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF262044), Color(0xFF7658F5)]), borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: _studentPurple.withOpacity(.18), blurRadius: 12, offset: const Offset(0, 5))]), child: const Center(child: Text('🐱', style: TextStyle(fontSize: 25))),), const SizedBox(width: 12), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('MOMOTASK STUDENT', style: TextStyle(color: _studentInk, fontWeight: FontWeight.w900, letterSpacing: .8, fontSize: 14)), Text('Your personal study space', style: TextStyle(color: _studentMuted, fontSize: 12))])), IconButton(tooltip: 'Log out', onPressed: onLogout, icon: const Icon(Icons.logout_rounded, color: _studentInk))]),
      const SizedBox(height: 22),
      Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF211C3B), Color(0xFF5B45B4)]), borderRadius: BorderRadius.circular(28), boxShadow: [BoxShadow(color: _studentPurple.withOpacity(.22), blurRadius: 25, offset: const Offset(0, 12))]), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [const Expanded(child: Text('YOUR STUDY POWER', style: TextStyle(color: Color(0xFFC9C0FF), letterSpacing: 1.5, fontSize: 11, fontWeight: FontWeight.w800))), Container(padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6), decoration: BoxDecoration(color: const Color(0xFFFFD37D).withOpacity(.18), borderRadius: BorderRadius.circular(30)), child: Text('✦ $medal', style: const TextStyle(color: Color(0xFFFFD37D), fontSize: 10, fontWeight: FontWeight.w900)))]),
        const SizedBox(height: 15), Row(crossAxisAlignment: CrossAxisAlignment.end, children: [Text('$xp', style: const TextStyle(color: Colors.white, fontSize: 44, height: 1, fontWeight: FontWeight.w900)), const Padding(padding: EdgeInsets.only(left: 8, bottom: 6), child: Text('XP earned', style: TextStyle(color: Color(0xFFD8D2F5), fontWeight: FontWeight.w600))), const Spacer(), const Text('🏆', style: TextStyle(fontSize: 34))]),
        const SizedBox(height: 17), ClipRRect(borderRadius: BorderRadius.circular(20), child: LinearProgressIndicator(value: progress, minHeight: 9, backgroundColor: Colors.white24, color: const Color(0xFFFFD37D))),
        const SizedBox(height: 8), Text(xp >= 60 ? 'Amazing! You reached the Gold milestone.' : '${nextMilestone - xp} XP to your next milestone', style: const TextStyle(color: Color(0xFFD8D2F5), fontSize: 11)),
      ])),
      const SizedBox(height: 17),
      _weeklyProgress(weeklyXp, weeklyTasks),
      const SizedBox(height: 17),
      LayoutBuilder(builder: (context, constraints) {
        const gap = 9.0;
        // Keep three compact cards on regular phones, but switch to a
        // two-column wrap on narrow devices to prevent cramped labels.
        final columns = constraints.maxWidth < 350 ? 2 : 3;
        final cardWidth = (constraints.maxWidth - gap * (columns - 1)) / columns;
        return Wrap(
          spacing: gap,
          runSpacing: gap,
          children: [
            SizedBox(width: cardWidth, child: _summary('COMPLETED', '${completed.length}', Icons.check_circle_rounded, const Color(0xFFE2F5ED), const Color(0xFF3A9B72))),
            SizedBox(width: cardWidth, child: _summary('IN REVIEW', '${pending.length}', Icons.hourglass_top_rounded, const Color(0xFFFFF1D9), const Color(0xFFC18B35))),
            SizedBox(width: cardWidth, child: _summary('TO DO', '${available.length}', Icons.bolt_rounded, const Color(0xFFECE8FF), _studentPurple)),
          ],
        );
      }),
      const SizedBox(height: 25),
      Row(children: [Container(width: 4, height: 22, decoration: BoxDecoration(color: _studentPurple, borderRadius: BorderRadius.circular(5))), const SizedBox(width: 9), const Expanded(child: Text('Your missions', style: TextStyle(color: _studentInk, fontWeight: FontWeight.w900, fontSize: 19))), Text('${missions.length} total', style: const TextStyle(color: _studentMuted, fontSize: 12))]), const SizedBox(height: 4), const Text('One focused step at a time. You’ve got this!', style: TextStyle(color: _studentMuted, fontSize: 11)), const SizedBox(height: 13),
      if (missions.isEmpty) Container(padding: const EdgeInsets.fromLTRB(20, 23, 20, 22), decoration: BoxDecoration(gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFFFFFFFF), Color(0xFFF0EDFF)]), borderRadius: BorderRadius.circular(22), border: Border.all(color: const Color(0xFFE7E1FF)), boxShadow: [BoxShadow(color: _studentPurple.withOpacity(.055), blurRadius: 18, offset: const Offset(0, 7))]), child: Column(children: [Container(width: 58, height: 58, decoration: BoxDecoration(color: const Color(0xFFE8E2FF), borderRadius: BorderRadius.circular(19)), child: const Icon(Icons.auto_awesome_rounded, color: _studentPurple, size: 28)), const SizedBox(height: 13), const Text('Your next little win is on its way!', textAlign: TextAlign.center, style: TextStyle(color: _studentInk, fontSize: 15, fontWeight: FontWeight.w900)), const SizedBox(height: 6), const Text('No missions just yet. When Admin shares a new mission, it will appear here. Take a breath—you’re right on track.', textAlign: TextAlign.center, style: TextStyle(color: _studentMuted, fontSize: 11, height: 1.5)), const SizedBox(height: 13), Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7), decoration: BoxDecoration(color: Colors.white.withOpacity(.85), borderRadius: BorderRadius.circular(30)), child: const Text('✨ READY WHEN YOU ARE', style: TextStyle(color: _studentPurple, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: .8))) ])),
      ...missions.map((m) => Padding(padding: const EdgeInsets.only(bottom: 12), child: MissionCard(mission: m, adminMode: false, onSubmit: m.status == MissionStatus.available ? () => onSubmit(m) : null))),
      const SizedBox(height: 14),
      Container(padding: const EdgeInsets.all(17), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(19), border: Border.all(color: const Color(0xFFECEAF3))), child: const Row(children: [Text('🥟', style: TextStyle(fontSize: 29)), SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Little steps, lovely rewards', style: TextStyle(color: _studentInk, fontWeight: FontWeight.w900)), SizedBox(height: 4), Text('Every mission you finish brings you closer to your next momo moment.', style: TextStyle(color: _studentMuted, fontSize: 11))]))])),
    ])))));
  }

  static Widget _weeklyProgress(List<int> xp, List<int> tasks) {
    const labels = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
    final maxValue = xp.fold<int>(0, (a, b) => a > b ? a : b);
    final totalXp = xp.fold<int>(0, (a, b) => a + b);
    final totalTasks = tasks.fold<int>(0, (a, b) => a + b);
    return Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), border: Border.all(color: const Color(0xFFECEAF3)), boxShadow: [BoxShadow(color: const Color(0xFF30245F).withOpacity(.035), blurRadius: 18, offset: const Offset(0, 7))]), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Container(width: 34, height: 34, decoration: BoxDecoration(color: const Color(0xFFECE8FF), borderRadius: BorderRadius.circular(11)), child: const Icon(Icons.insights_rounded, color: _studentPurple, size: 19)), const SizedBox(width: 10), const Expanded(child: Text('Weekly activity', style: TextStyle(color: _studentInk, fontWeight: FontWeight.w900, fontSize: 16))), Container(padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7), decoration: BoxDecoration(color: const Color(0xFFF1EEFF), borderRadius: BorderRadius.circular(12)), child: Text('$totalXp XP', style: const TextStyle(color: _studentPurple, fontWeight: FontWeight.w900, fontSize: 12)))]),
      const SizedBox(height: 5), Text('$totalTasks approved ${totalTasks == 1 ? 'mission' : 'missions'} · XP earned each day', style: const TextStyle(color: _studentMuted, fontSize: 11)),
      const SizedBox(height: 17), SizedBox(height: 104, child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: List.generate(7, (i) { final ratio = maxValue == 0 ? 0.0 : xp[i] / maxValue; return Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 5), child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [Text(xp[i] == 0 ? '' : '${xp[i]}', style: const TextStyle(color: _studentMuted, fontSize: 9, fontWeight: FontWeight.w700)), const SizedBox(height: 5), Container(height: 66, alignment: Alignment.bottomCenter, child: FractionallySizedBox(heightFactor: ratio == 0 ? .045 : ratio, child: Container(decoration: BoxDecoration(gradient: const LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [Color(0xFF7658F5), Color(0xFFAA98FF)]), borderRadius: BorderRadius.circular(8))))), const SizedBox(height: 7), Text(labels[i], style: const TextStyle(color: _studentMuted, fontSize: 10, fontWeight: FontWeight.w700))]))); }))),
      if (totalTasks == 0) Padding(padding: const EdgeInsets.only(top: 12), child: Container(width: double.infinity, padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10), decoration: BoxDecoration(color: const Color(0xFFF7F5FF), borderRadius: BorderRadius.circular(12)), child: const Row(children: [Icon(Icons.tips_and_updates_outlined, color: _studentPurple, size: 16), SizedBox(width: 8), Expanded(child: Text('Your approved mission activity will appear here as you earn XP.', style: TextStyle(color: _studentMuted, fontSize: 10, height: 1.4)))]))),
    ]));
  }

  static Widget _summary(String label, String value, IconData icon, Color bg, Color fg) => Container(padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 11), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(19), border: Border.all(color: const Color(0xFFECEAF3)), boxShadow: [BoxShadow(color: const Color(0xFF30245F).withOpacity(.025), blurRadius: 12, offset: const Offset(0, 5))]), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Container(width: 31, height: 31, decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(10)), child: Icon(icon, color: fg, size: 17)), const SizedBox(height: 9), Text(value, style: const TextStyle(color: _studentInk, fontWeight: FontWeight.w900, fontSize: 21)), Text(label, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _studentMuted, fontSize: 9, height: 1.2, fontWeight: FontWeight.w800, letterSpacing: .2))]));
}
