import 'package:flutter/material.dart';
import '../models/mission.dart';
import '../widgets/mission_card.dart';

const _ink = Color(0xFF17152D);
const _muted = Color(0xFF89879B);
const _purple = Color(0xFF7658F5);
const _canvas = Color(0xFFF6F5FB);

class AdminScreen extends StatelessWidget {
  const AdminScreen({super.key, required this.missions, required this.onAddMission, required this.onApprove, required this.onLogout});

  final List<Mission> missions;
  final ValueChanged<Mission> onAddMission;
  final ValueChanged<Mission> onApprove;
  final VoidCallback onLogout;

  Future<void> _createMission(BuildContext context, {String? presetTitle, String? presetCategory}) async {
    final title = TextEditingController(text: presetTitle ?? '');
    final details = TextEditingController();
    final points = TextEditingController(text: '10');
    final formKey = GlobalKey<FormState>();
    final result = await showDialog<bool>(context: context, builder: (ctx) => Dialog(
      insetPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 24),
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.fromLTRB(21, 21, 21, 17),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(26), border: Border.all(color: const Color(0xFFECEAF3)), boxShadow: [BoxShadow(color: _ink.withOpacity(.12), blurRadius: 28, offset: const Offset(0, 12))]),
        child: SafeArea(child: Form(key: formKey, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Container(width: 42, height: 42, decoration: BoxDecoration(color: const Color(0xFFECE8FF), borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.auto_awesome_rounded, color: _purple)), const SizedBox(width: 12), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Create a mission', style: TextStyle(color: _ink, fontSize: 19, fontWeight: FontWeight.w900)), SizedBox(height: 3), Text('Make the next study win count.', style: TextStyle(color: _muted, fontSize: 11))]))]),
          const SizedBox(height: 21),
          _missionField(title, 'Mission title', Icons.flag_outlined, validator: (v) => (v == null || v.trim().isEmpty) ? 'Add a title' : null),
          const SizedBox(height: 12),
          _missionField(details, 'Instructions (optional)', Icons.notes_rounded, maxLines: 3),
          const SizedBox(height: 12),
          _missionField(points, 'XP points', Icons.bolt_rounded, keyboardType: TextInputType.number, validator: (v) { final value = int.tryParse(v ?? ''); return value == null || value < 1 ? 'Enter at least 1 XP' : null; }),
          const SizedBox(height: 20),
          Row(children: [Expanded(child: OutlinedButton(onPressed: () => Navigator.pop(ctx, false), style: OutlinedButton.styleFrom(foregroundColor: _muted, side: const BorderSide(color: Color(0xFFE7E4EF)), padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))), child: const Text('Cancel'))), const SizedBox(width: 10), Expanded(child: FilledButton(onPressed: () { if (formKey.currentState!.validate()) Navigator.pop(ctx, true); }, style: FilledButton.styleFrom(backgroundColor: _purple, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))), child: const Text('Create mission', style: TextStyle(fontWeight: FontWeight.w800))))]),
        ])))),
      ),
    ));
    if (result == true) onAddMission(Mission(id: DateTime.now().microsecondsSinceEpoch.toString(), title: title.text.trim(), description: details.text.trim().isEmpty ? 'Complete this study mission.' : details.text.trim(), points: int.parse(points.text), category: presetCategory ?? 'Study', dueLabel: 'Today'));
    title.dispose(); details.dispose(); points.dispose();
  }

  static Widget _missionField(TextEditingController controller, String label, IconData icon, {int maxLines = 1, TextInputType? keyboardType, String? Function(String?)? validator}) => TextFormField(
    controller: controller,
    maxLines: maxLines,
    keyboardType: keyboardType,
    validator: validator,
    style: const TextStyle(color: _ink, fontSize: 13, fontWeight: FontWeight.w600),
    decoration: InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: _muted, fontSize: 12),
      prefixIcon: Icon(icon, color: _purple, size: 19),
      alignLabelWithHint: maxLines > 1,
      filled: true,
      fillColor: const Color(0xFFF8F7FC),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: Color(0xFFECEAF3))),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: _purple, width: 1.4)),
      errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: Color(0xFFE16B75))),
    ),
  );

  Future<void> _previewTemplate(BuildContext context, {required String title, required String emoji, required String subtitle, required Color color, required String presetTitle, required String category}) async {
    final use = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        padding: const EdgeInsets.fromLTRB(22, 12, 22, 26),
        decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(30))),
        child: SafeArea(child: ConstrainedBox(constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * .84), child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Center(child: Container(width: 42, height: 4, decoration: BoxDecoration(color: const Color(0xFFE7E5EE), borderRadius: BorderRadius.circular(8)))),
          const SizedBox(height: 18),
          const Text('TEMPLATE PREVIEW', style: TextStyle(color: _purple, fontSize: 10, letterSpacing: 1.5, fontWeight: FontWeight.w900)),
          const SizedBox(height: 12),
          Container(height: 156, width: double.infinity, decoration: BoxDecoration(gradient: LinearGradient(colors: [color, color.withOpacity(.55)], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(24), boxShadow: [BoxShadow(color: color.withOpacity(.45), blurRadius: 18, offset: const Offset(0, 8))]), child: Stack(alignment: Alignment.center, children: [Positioned(top: 12, right: 14, child: Icon(Icons.auto_awesome_rounded, color: Colors.white.withOpacity(.8), size: 20)), Text(emoji, style: const TextStyle(fontSize: 66))])),
          const SizedBox(height: 18),
          Text(title, style: const TextStyle(color: _ink, fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          Text(subtitle, style: const TextStyle(color: _muted, fontSize: 13, height: 1.45)),
          const SizedBox(height: 17),
          Container(width: double.infinity, padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: const Color(0xFFF6F4FC), borderRadius: BorderRadius.circular(17)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('SUGGESTED MISSION', style: TextStyle(color: _muted, fontSize: 9, letterSpacing: 1.2, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6), Text(presetTitle, style: const TextStyle(color: _ink, fontSize: 15, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4), Text('$category · You can edit title, instructions and XP next', style: const TextStyle(color: _muted, fontSize: 11)),
          ])),
          const SizedBox(height: 18),
          Row(children: [Expanded(child: OutlinedButton(onPressed: () => Navigator.pop(ctx, false), style: OutlinedButton.styleFrom(foregroundColor: _muted, side: const BorderSide(color: Color(0xFFE7E4EF)), padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))), child: const Text('Not now'))), const SizedBox(width: 10), Expanded(child: FilledButton.icon(onPressed: () => Navigator.pop(ctx, true), icon: const Icon(Icons.arrow_forward_rounded, size: 17), label: const Text('Use template'), style: FilledButton.styleFrom(backgroundColor: _purple, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)), textStyle: const TextStyle(fontWeight: FontWeight.w800))))]),
        ])))),
      ),
    );
    if (use == true && context.mounted) {
      await _createMission(context, presetTitle: presetTitle, presetCategory: category);
    }
  }

  @override
  Widget build(BuildContext context) {
    final pending = missions.where((m) => m.status == MissionStatus.submitted).toList();
    final active = missions.where((m) => m.status == MissionStatus.available).length;
    final completed = missions.where((m) => m.status == MissionStatus.approved).length;
    return Scaffold(backgroundColor: _canvas, body: SafeArea(child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 720), child: ListView(padding: const EdgeInsets.fromLTRB(18, 12, 18, 28), children: [
      Row(children: [Container(width: 46, height: 46, decoration: BoxDecoration(color: _ink, borderRadius: BorderRadius.circular(15)), child: const Icon(Icons.bolt_rounded, color: Color(0xFFFFC96B), size: 27)), const SizedBox(width: 12), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('MOMOTASK ADMIN', style: TextStyle(color: _ink, fontWeight: FontWeight.w900, letterSpacing: 1.1, fontSize: 16)), Text('Your mission control', style: TextStyle(color: _muted, fontSize: 12))])), IconButton(onPressed: onLogout, icon: const Icon(Icons.logout_rounded, color: _ink))]),
      const SizedBox(height: 22),
      Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF262044), Color(0xFF5540A8)]), borderRadius: BorderRadius.circular(26), boxShadow: [BoxShadow(color: _purple.withOpacity(.18), blurRadius: 22, offset: const Offset(0, 10))]), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [const Expanded(child: Text('ADMIN STUDIO', style: TextStyle(color: Color(0xFFC9C0FF), letterSpacing: 1.6, fontSize: 11, fontWeight: FontWeight.w800))), Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: Colors.white.withOpacity(.12), borderRadius: BorderRadius.circular(30)), child: const Text('LIVE BOARD', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700)))]),
        const SizedBox(height: 15), const Text('Build her next\nbig study win.', style: TextStyle(color: Colors.white, fontSize: 27, height: 1.12, fontWeight: FontWeight.w900)), const SizedBox(height: 8), const Text('Small missions. Real progress. Lovely rewards.', style: TextStyle(color: Color(0xFFD8D2F5), fontSize: 12)), const SizedBox(height: 20),
        Row(children: [Expanded(child: _heroStat('ACTIVE', '$active', Icons.bolt_rounded)), const SizedBox(width: 10), Expanded(child: _heroStat('TO REVIEW', '${pending.length}', Icons.fact_check_outlined)), const SizedBox(width: 10), Expanded(child: _heroStat('DONE', '$completed', Icons.check_circle_outline))]),
      ])),
      const SizedBox(height: 25),
      Row(children: [const Expanded(child: Text('Quick create', style: TextStyle(color: _ink, fontWeight: FontWeight.w900, fontSize: 19))), FilledButton.icon(onPressed: () => _createMission(context), icon: const Icon(Icons.add_rounded, size: 17), label: const Text('New mission'), style: FilledButton.styleFrom(backgroundColor: _purple, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))))]),
      const SizedBox(height: 9),
      const Padding(padding: EdgeInsets.only(bottom: 10), child: Text('Choose a starting vibe, then customise the mission.', style: TextStyle(color: _muted, fontSize: 11, height: 1.35))),
      SizedBox(height: 154, child: ListView(scrollDirection: Axis.horizontal, physics: const BouncingScrollPhysics(), children: [
        _template('Minimal', '✦', const Color(0xFFECE8FF), 'Clean and calm study missions', () => _previewTemplate(context, title: 'Minimal & Aesthetic', emoji: '✦', subtitle: 'A quiet, distraction-free look for focused study sessions.', color: const Color(0xFFECE8FF), presetTitle: 'Focused study session', category: 'Study')),
        _template('Robotic', '🤖', const Color(0xFFDDF6F1), 'Futuristic challenge style', () => _previewTemplate(context, title: 'Robotic / Sci-Fi', emoji: '🤖', subtitle: 'A futuristic mission look for ambitious study challenges.', color: const Color(0xFFDDF6F1), presetTitle: 'Tech challenge', category: 'Challenge')),
        _template('Cinematic', '🎬', const Color(0xFFFFE5DF), 'Movie-inspired atmosphere', () => _previewTemplate(context, title: 'Cinematic Series', emoji: '🎬', subtitle: 'Original cinematic visuals inspired by mystery and heist moods.', color: const Color(0xFFFFE5DF), presetTitle: 'Cinematic study challenge', category: 'Challenge')),
        _template('Comedy', '🎤', const Color(0xFFFFF0D5), 'Playful comedy energy', () => _previewTemplate(context, title: 'Comedy Theme', emoji: '🎤', subtitle: 'A lively stage-inspired style for fun learning missions.', color: const Color(0xFFFFF0D5), presetTitle: 'Fun learning challenge', category: 'Fun')),
        _template('Football', '⚽', const Color(0xFFE2EEFF), 'Champion mindset', () => _previewTemplate(context, title: 'Football Legend', emoji: '⚽', subtitle: 'A stadium-inspired visual for discipline and consistency.', color: const Color(0xFFE2EEFF), presetTitle: 'Champion study sprint', category: 'Challenge')),
        _template('Momo treat', '🥟', const Color(0xFFFFE8E0), 'Food reward celebration', () => _previewTemplate(context, title: 'Food Reward', emoji: '🥟', subtitle: 'A cute reward theme for momo, kacchi, burger, pizza and more.', color: const Color(0xFFFFE8E0), presetTitle: 'Momo reward mission', category: 'Reward')),
        _template('Adventure', '🏔️', const Color(0xFFE3F2E5), 'Explore and conquer', () => _previewTemplate(context, title: 'Adventure', emoji: '🏔️', subtitle: 'Mountain and expedition-inspired challenge visuals.', color: const Color(0xFFE3F2E5), presetTitle: 'Adventure study quest', category: 'Challenge')),
        _template('Neon series', '🌌', const Color(0xFFEAE5FF), 'Neon cinematic look', () => _previewTemplate(context, title: 'Neon Series', emoji: '🌌', subtitle: 'A bold neon visual for special study missions.', color: const Color(0xFFEAE5FF), presetTitle: 'Neon focus mission', category: 'Study')),
      ])),
      const SizedBox(height: 24),
      Row(children: [Container(width: 4, height: 22, decoration: BoxDecoration(color: _purple, borderRadius: BorderRadius.circular(5))), const SizedBox(width: 9), const Expanded(child: Text('Mission board', style: TextStyle(color: _ink, fontWeight: FontWeight.w900, fontSize: 19))), Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: const Color(0xFFEDEAFF), borderRadius: BorderRadius.circular(30)), child: Text('${missions.length} TOTAL', style: const TextStyle(color: _purple, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: .5)))]), const SizedBox(height: 10),
      if (missions.isEmpty) _empty('Your board is clear', 'Create the first mission for Sumaiya.'),
      ...missions.map((m) => Padding(padding: const EdgeInsets.only(bottom: 9), child: MissionCard(mission: m, adminMode: true))),
      const SizedBox(height: 17),
      Row(children: [Container(width: 4, height: 22, decoration: BoxDecoration(color: const Color(0xFFE3A44B), borderRadius: BorderRadius.circular(5))), const SizedBox(width: 9), const Expanded(child: Text('Needs your review', style: TextStyle(color: _ink, fontWeight: FontWeight.w900, fontSize: 19))), if (pending.isNotEmpty) _countPill('${pending.length}')]), const SizedBox(height: 5), const Padding(padding: EdgeInsets.only(left: 13), child: Text('Check each submission before approving XP.', style: TextStyle(color: _muted, fontSize: 11))), const SizedBox(height: 10),
      if (pending.isEmpty) _empty('All caught up', 'New student submissions will appear here.'),
      ...pending.map((m) => _reviewCard(m)),
      const SizedBox(height: 14), Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFFEDEAFF), borderRadius: BorderRadius.circular(16)), child: const Row(children: [Icon(Icons.cloud_done_rounded, color: _purple), SizedBox(width: 10), Expanded(child: Text('Live mission data is loaded from your MOMOTASK Firebase workspace.', style: TextStyle(color: Color(0xFF554A83), fontSize: 12, fontWeight: FontWeight.w600)))])),
    ])))));
  }


  Widget _reviewCard(Mission mission) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(19),
        border: Border.all(color: const Color(0xFFF0E8D8)),
        boxShadow: [BoxShadow(color: const Color(0xFF8A6A38).withOpacity(.045), blurRadius: 12, offset: const Offset(0, 4))],
      ),
      child: LayoutBuilder(builder: (context, constraints) {
        final narrow = constraints.maxWidth < 330;
        final details = Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(mission.title, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: _ink, fontWeight: FontWeight.w800, fontSize: 13, height: 1.25)),
            const SizedBox(height: 5),
            Row(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.stars_rounded, color: Color(0xFFC18B35), size: 13),
              const SizedBox(width: 4),
              Text('${mission.points} XP', style: const TextStyle(color: Color(0xFF9B7130), fontSize: 10, fontWeight: FontWeight.w800)),
              const SizedBox(width: 7),
              const Flexible(child: Text('Student submission', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: _muted, fontSize: 10))),
            ]),
          ]),
        );
        final approve = FilledButton.icon(
          onPressed: () => onApprove(mission),
          icon: const Icon(Icons.check_rounded, size: 16),
          label: const Text('Approve'),
          style: FilledButton.styleFrom(backgroundColor: _purple, foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
        );
        return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(width: 42, height: 42, decoration: BoxDecoration(color: const Color(0xFFFFF1D9), borderRadius: BorderRadius.circular(13)),
              child: const Icon(Icons.fact_check_rounded, color: Color(0xFFC18B35), size: 21)),
            const SizedBox(width: 11),
            details,
            if (!narrow) ...[const SizedBox(width: 8), approve],
          ]),
          if (narrow) Padding(padding: const EdgeInsets.only(left: 53, top: 10), child: approve),
        ]);
      }),
    );
  }

  static Widget _heroStat(String label, String value, IconData icon) => Container(padding: const EdgeInsets.all(11), decoration: BoxDecoration(color: Colors.white.withOpacity(.11), borderRadius: BorderRadius.circular(15)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: const Color(0xFFFFD37D), size: 17), const SizedBox(height: 7), Text(value, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)), Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFFD8D2F5), fontSize: 9, fontWeight: FontWeight.w700, letterSpacing: .5))]));
  static Widget _template(String title, String emoji, Color color, String subtitle, VoidCallback onTap) => GestureDetector(onTap: onTap, child: Container(width: 150, margin: const EdgeInsets.only(right: 10), padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFECEAF3)), boxShadow: [BoxShadow(color: _ink.withOpacity(.035), blurRadius: 12, offset: const Offset(0, 4))]), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Container(height: 72, width: double.infinity, decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [color, color.withOpacity(.55)]), borderRadius: BorderRadius.circular(15)), child: Stack(children: [Positioned(right: 8, top: 7, child: Icon(Icons.auto_awesome_rounded, color: Colors.white.withOpacity(.65), size: 15)), Center(child: Text(emoji, style: const TextStyle(fontSize: 30)))])), const Spacer(), Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _ink, fontWeight: FontWeight.w900, fontSize: 12)), const SizedBox(height: 2), Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _muted, fontSize: 9, height: 1.2))])));
  static Widget _empty(String title, String subtitle) => Container(
    width: double.infinity,
    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
    decoration: BoxDecoration(
      gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFFFFFFFF), Color(0xFFF7F5FF)]),
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: const Color(0xFFE9E5F7)),
      boxShadow: [BoxShadow(color: _purple.withOpacity(.045), blurRadius: 16, offset: const Offset(0, 5))],
    ),
    child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
      Container(width: 48, height: 48, decoration: BoxDecoration(color: const Color(0xFFEDEAFF), borderRadius: BorderRadius.circular(16)), child: const Icon(Icons.auto_awesome_rounded, color: _purple, size: 23)),
      const SizedBox(width: 13),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(color: _ink, fontWeight: FontWeight.w900, fontSize: 13)),
        const SizedBox(height: 4),
        Text(subtitle, style: const TextStyle(color: _muted, fontSize: 11, height: 1.35)),
      ])),
    ]),
  );
  static Widget _countPill(String value) => Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), decoration: BoxDecoration(color: const Color(0xFFFFE9E5), borderRadius: BorderRadius.circular(30)), child: Text(value, style: const TextStyle(color: Color(0xFFC35F4F), fontWeight: FontWeight.w800)));
}

