import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../models/mission.dart';
import 'admin_screen.dart';
import 'student_screen.dart';

class AppShell extends StatefulWidget {
  final String role;
  const AppShell({super.key, required this.role});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  final _missions = FirebaseFirestore.instance.collection('missions');

  Mission _fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data() ?? {};
    final rawStatus = data['status'] as String? ?? 'available';
    final status = MissionStatus.values.firstWhere(
      (value) => value.name == rawStatus,
      orElse: () => MissionStatus.available,
    );
    return Mission(
      id: doc.id,
      title: data['title'] as String? ?? 'Untitled mission',
      description: data['description'] as String? ?? '',
      points: (data['points'] as num?)?.toInt() ?? 0,
      category: data['category'] as String? ?? 'Study',
      dueLabel: data['dueLabel'] as String? ?? 'Today',
      status: status,
      createdBy: data['createdBy'] as String? ?? 'admin',
    );
  }

  Future<void> _addMission(Mission mission) async {
    await _missions.doc(mission.id).set({
      'title': mission.title,
      'description': mission.description,
      'points': mission.points,
      'category': mission.category,
      'dueLabel': mission.dueLabel,
      'status': MissionStatus.available.name,
      'createdBy': FirebaseAuth.instance.currentUser?.uid ?? 'admin',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> _submitMission(Mission mission) async {
    await _missions.doc(mission.id).update({
      'status': MissionStatus.submitted.name,
      'submittedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> _approveMission(Mission mission) async {
    await _missions.doc(mission.id).update({
      'status': MissionStatus.approved.name,
      'approvedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> _logout() async => FirebaseAuth.instance.signOut();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: _missions.orderBy('createdAt', descending: true).snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Scaffold(body: Center(child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text('Could not load missions. Check Firestore access and internet connection.\n\n${snapshot.error}', textAlign: TextAlign.center),
          )));
        }
        if (!snapshot.hasData) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        final missions = snapshot.data!.docs.map(_fromDoc).toList();
        final xp = missions.where((m) => m.status == MissionStatus.approved)
            .fold<int>(0, (total, m) => total + m.points);
        if (widget.role == 'admin') {
          return AdminScreen(missions: missions, onAddMission: _addMission,
              onApprove: _approveMission, onLogout: _logout);
        }
        return StudentScreen(missions: missions, xp: xp, onSubmit: _submitMission,
            onSwitchRole: () {}, onLogout: _logout);
      },
    );
  }
}
