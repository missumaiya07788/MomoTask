# MOMOTASK — Flutter Android Prototype

A cute, gamified study companion prototype for Sumaiya.

## Current prototype features
- Admin dashboard and Student dashboard preview
- Switch between Admin and Student preview using the top-right swap icon
- Admin can create missions with title, instructions and XP
- Student can submit available missions
- Admin can approve submitted missions
- XP is added after approval
- Sample missions included

## Important prototype limitation
This first version is a **local interactive prototype**. The data is held in app memory and resets when the app restarts. Firebase packages are listed in `pubspec.yaml`, but Firebase has not yet been configured. Online sync, secure login, persistent storage, notifications, and APK signing are the next development phase.

## Requirements
- Flutter SDK (stable)
- Android Studio or Android SDK
- A computer for building the APK

## Run
```bash
flutter pub get
flutter run
```

## Build APK
```bash
flutter build apk --release
```
The output will be:
`build/app/outputs/flutter-apk/app-release.apk`

## Suggested next phase: Firebase online sync
1. Create a Firebase project named `momotask`.
2. Register the Android app using your final Android application ID.
3. Install FlutterFire CLI and run `flutterfire configure`.
4. Initialize Firebase in `main.dart`.
5. Add Firebase Authentication for Admin and Student accounts.
6. Add Firestore collections:
   - `users`
   - `missions`
   - `submissions`
   - `rewards`
   - `study_sessions`
7. Add Firestore Security Rules so only the Admin can create/edit missions and approve submissions. Student can read assigned missions and submit completion.

## Recommended user roles
- `admin`: creates missions, reviews submissions, awards bonus XP, manages rewards.
- `student`: views missions, tracks study time, submits completion, sees XP and progress.

## Mission generation
For the first online release, the app should support:
- Admin-created missions
- App-suggested mission templates, requiring Admin approval before publishing

Do not let an unverified client award XP directly. XP should be granted only by trusted backend logic or an Admin-authorized operation.
