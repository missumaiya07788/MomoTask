# Student APK Launcher Icon

Student-only launcher icon assets and the resource-copy script are included in this source package.

After the GitHub Actions workflow generates the Android project (`flutter create`), and before it builds the APKs, run:

```bash
bash scripts/apply_student_launcher_icon.sh
```

This writes the icon only to `android/app/src/student/res`, so the Admin flavor's launcher icon remains unchanged. The workflow must execute this command after Android project generation and before `flutter build ... --flavor student`.
