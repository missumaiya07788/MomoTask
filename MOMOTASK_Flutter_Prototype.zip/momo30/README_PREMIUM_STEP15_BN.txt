MOMOTASK Premium UI – Step 15

Admin Approval / Review Card visual refinement:
- Added a clear SUBMITTED status pill.
- Grouped status and XP metadata with responsive wrapping.
- Refined the review card border and shadow to make pending submissions easier to scan.

No Firestore, authentication, mission status, approval callback, or XP logic was intentionally changed.
Build and flutter analyze have not been run in this environment.
