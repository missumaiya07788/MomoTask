# MOMOTASK Firestore setup

এই source-এ Admin/Student mission sync `missions` collection দিয়ে করা হয়েছে। Firebase Console → Firestore Database → Rules-এ নিচের rules বসিয়ে Publish করুন।

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    function signedIn() { return request.auth != null; }
    function role() {
      return get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role;
    }
    match /users/{uid} {
      allow read: if signedIn() && request.auth.uid == uid;
      allow write: if false;
    }
    match /missions/{missionId} {
      allow read: if signedIn() && role() in ['admin', 'student'];
      allow create: if signedIn() && role() == 'admin' && request.resource.data.status == 'available';
      allow update: if signedIn() && (
        (role() == 'student' && resource.data.status == 'available'
          && request.resource.data.status == 'submitted'
          && request.resource.data.diff(resource.data).affectedKeys().hasOnly(['status', 'submittedAt']))
        ||
        (role() == 'admin' && resource.data.status == 'submitted'
          && request.resource.data.status == 'approved'
          && request.resource.data.diff(resource.data).affectedKeys().hasOnly(['status', 'approvedAt']))
      );
      allow delete: if signedIn() && role() == 'admin';
    }
  }
}
```

প্রথম mission Admin থেকে save করলে `missions` collection নিজে তৈরি হবে। Rules publish না করলে permission error আসবে। XP অনুমোদিত mission-এর Firestore data থেকে হিসাব হয়।
