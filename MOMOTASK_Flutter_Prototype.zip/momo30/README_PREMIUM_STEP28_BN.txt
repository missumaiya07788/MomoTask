STEP 28 — STUDENT XP BREAKDOWN

Student Profile-এ XP BREAKDOWN অংশ যোগ করা হয়েছে। এখানে তিনটি মান দেখা যাবে:
1. Approved mission rewards: xp_earnings ledger থেকে মোট XP.
2. Admin adjustments: xp_adjustments থেকে যোগ/বিয়োগের নিট পরিমাণ.
3. Current total: দুইটির যোগফল, যা Student Dashboard-এর XP-এর সঙ্গে মিলে।

এটি কেবল বিদ্যমান Firebase stream-এর হিসাব দৃশ্যমান করে; নতুন collection বা Rules permission যোগ করে না। Step 27-এর xp_earnings এবং xp_adjustments Rules অপরিবর্তিত রাখুন।

সীমাবদ্ধতা: Flutter SDK এখানে নেই, তাই flutter analyze/build এবং Firebase বাস্তব পরীক্ষা করা হয়নি। ZIP integrity check করা হয়েছে মাত্র।
