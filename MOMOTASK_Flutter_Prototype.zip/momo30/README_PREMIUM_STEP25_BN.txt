MOMOTASK PREMIUM — STEP 25

নতুন ফিচার: XP Control & Profile Notifications

Admin APK:
- Sumaiya-র বর্তমান মোট XP দেখায়।
- Add XP এবং Remove XP অপশন আছে।
- Remove XP-এর Reason বাধ্যতামূলক; Add XP-এর Message ঐচ্ছিক।
- প্রতিটি পরিবর্তন xp_adjustments collection-এ আলাদা রেকর্ড হয়।

Student APK:
- মোট XP = Approved Mission XP + সব Admin XP Adjustment।
- Profile-এ XP Notifications ও তারিখ/সময় দেখা যায়।

Firebase Rules:
- এই সোর্সের জন্য Firestore Rules-এ xp_adjustments collection-এর অনুমতি থাকতে হবে (ব্যবহারকারী Step 25-এর আগে Rules publish করেছেন)।

গুরুত্বপূর্ণ যাচাই:
- Flutter SDK এই পরিবেশে নেই; flutter analyze/build চালানো হয়নি।
- বাস্তব Firebase test হয়নি।
- Sumaiya Student UID সোর্সে বর্তমান MOMOTASK Firebase account অনুযায়ী নির্দিষ্ট করা আছে।
- Firebase index প্রয়োজন হলে Console-এর error link অনুসরণ করে index তৈরি করতে হবে।
