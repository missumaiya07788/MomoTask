MOMOTASK Premium UI — Step36

এই ধাপে Student Dashboard-এর Progress Counter-এর একটি হিসাবের সমস্যা ঠিক করা হয়েছে।

পরিবর্তন:
1. Dashboard-এর COMPLETED কাউন্ট এখন শুধু Active List-এর সর্বশেষ ১০টি Mission নয়, বরং App-এ পাওয়া সম্পূর্ণ retained mission history থেকে হিসাব হয়।
2. IN REVIEW কাউন্টেও Archived অবস্থায় থাকা submitted mission অন্তর্ভুক্ত হয়।
3. Active mission list আগের মতো সর্বশেষ ১০টি non-archived mission-ই দেখায়।
4. UI Design, XP হিসাব, Firebase Rules বা Mission workflow-তে অন্য কোনো পরিবর্তন করা হয়নি।

কেন দরকার:
পুরোনো Mission archive হলে Student-এর Dashboard-এ completed task সংখ্যা কমে যাচ্ছিল। এখন Archive হওয়া মানেই progress count থেকে বাদ পড়বে না।

পরীক্ষা:
ZIP integrity যাচাই করা হয়েছে। Flutter/Dart SDK অনুপস্থিত থাকায় flutter analyze/build এবং APK runtime test চালানো হয়নি।
