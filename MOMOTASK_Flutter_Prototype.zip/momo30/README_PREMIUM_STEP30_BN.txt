MOMOTASK Premium UI – Step 30

এই ধাপে XP Control-এর নিরাপত্তা ও Firebase Rules-এর optional message নিয়ম পরিষ্কার করা হয়েছে।

১) Admin APK-তে XP কমানোর সময় বর্তমান XP balance-এর চেয়ে বেশি XP কাটতে চাইলে Form এখন বাধা দেবে। এতে সাধারণ ভুলে মোট XP ঋণাত্মক হওয়ার ঝুঁকি কমে। এটি UI validation; Firestore Rules একা সব collection-এর যোগফল যাচাই করতে পারে না, তাই ভবিষ্যতে server-side trusted function দিয়ে এই সীমা enforce করা সবচেয়ে নিরাপদ।

২) Firebase Rules পরিবর্তন: আগের xp_adjustments match block-টি নিচের block দিয়ে প্রতিস্থাপন করতে হবে। অন্য match block, বিশেষ করে missions, xp_earnings এবং catch-all block অপরিবর্তিত থাকবে।

match /xp_adjustments/{adjustmentId} {
  allow create: if isAdmin()
    && request.resource.data.keys().hasAll([
      'studentUid', 'xpDelta', 'reason', 'createdAt', 'createdBy'
    ])
    && request.resource.data.studentUid is string
    && request.resource.data.xpDelta is int
    && request.resource.data.xpDelta != 0
    && request.resource.data.reason is string
    && (request.resource.data.xpDelta > 0
        || request.resource.data.reason.size() > 0)
    && request.resource.data.createdBy == request.auth.uid;

  allow read: if isAdmin()
    || (isStudent() && resource.data.studentUid == request.auth.uid);

  allow update, delete: if false;
}

এর ফলে:
- XP কমালে Reason বাধ্যতামূলক থাকবে।
- XP বাড়ালে Message ফাঁকা রাখা যাবে।
- Admin সব adjustment পড়তে পারবে।
- Student শুধু নিজের adjustment পড়তে পারবে।
- Adjustment record update/delete করা যাবে না।

গুরুত্বপূর্ণ: Firebase Rules পরিবর্তনটি Console → Firestore Database → Rules-এ গিয়ে আগের xp_adjustments block-এর জায়গায় বসিয়ে Publish করতে হবে। পুরো Rules মুছতে হবে না।

যাচাইয়ের সীমা:
- ZIP archive integrity পরীক্ষা করা হয়েছে।
- Flutter SDK/Build এখানে চালানো হয়নি; flutter analyze, APK build এবং live Firebase test করা হয়নি।
- UI validation security boundary নয়। সম্পূর্ণ server-side non-negative XP enforcement-এর জন্য trusted Cloud Function/Callable backend প্রয়োজন।
