STEP 27 — XP BACKFILL SAFETY + WEEKLY LEDGER

এই ধাপে retention cleanup-এর আগে সব বিদ্যমান Approved Mission-এর XP `xp_earnings`-এ backfill করা হয়। Document ID mission ID হওয়ায় একই কাজ বারবার চললেও duplicate XP তৈরি হয় না। ফলে এক মাসের পুরোনো mission cleanup হওয়ার আগে তার XP ledger-এ সুরক্ষিত থাকে। Weekly XP chart-ও এখন `xp_earnings` ledger থেকে হিসাব করে, মুছে যাওয়া mission document-এর ওপর নির্ভর করে না।

গুরুত্বপূর্ণ: যেসব mission Step 26/27 চালুর আগেই স্থায়ীভাবে delete হয়েছে, সেগুলোর XP Firestore থেকে আর backfill করা সম্ভব নাও হতে পারে। সেগুলোর জন্য backup/export দরকার হতে পারে।

এই backfill চালাতে Admin APK-তে লগইন থাকা অবস্থায় AppShell-এর retention maintenance চলতে হবে। Rules-এ Admin-এর `xp_earnings` read এবং create permission থাকতে হবে।
