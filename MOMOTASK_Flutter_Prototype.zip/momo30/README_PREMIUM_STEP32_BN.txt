MOMOTASK PREMIUM UI — STEP 32

এই ধাপে Admin XP adjustment-এর হিসাব Firestore transaction-এর মধ্যে নেওয়া হয়েছে।

পরিবর্তন:
1. XP Adjustment লেখার আগে transaction-এর ভেতরে Approved Mission XP এবং আগের Admin Adjustment আবার পড়া হয়।
2. সর্বশেষ মোট XP অনুযায়ী কমানোর সীমা যাচাই হয়; মোট XP ০-এর নিচে যাওয়ার চেষ্টা হলে লেখা বন্ধ হয়।
3. Transaction retry হলে একই adjustment document reference ব্যবহার হয়; একই transaction-এর retry-তে duplicate ledger document তৈরি হয় না।
4. operationId field সংরক্ষণ করা হয়।
5. আগের নিয়ম অপরিবর্তিত: যোগে message ঐচ্ছিক, বিয়োগে reason বাধ্যতামূলক।

গুরুত্বপূর্ণ সীমাবদ্ধতা:
- এটি client-side Firestore transaction; Cloud Functions/server-side validation নয়।
- আলাদা করে Admin একই কাজ দ্বিতীয়বার Confirm করলে সেটি নতুন adjustment হিসেবে গণ্য হবে। UI-level double-submit lock এবং server-side callable function পরবর্তী নিরাপত্তা ধাপ।
- Firestore Rules-এ operationId uniqueness বা balance check enforce করা হয়নি।
- Flutter SDK এই পরিবেশে নেই; flutter analyze/build চালানো হয়নি।
