MOMOTASK Premium UI Step 12
- Student/Admin mission details bottom sheet: added a clear close control.
- Refined task details hierarchy and instruction panel contrast/spacing.
- Kept mission data, Firebase, submission callback, approval and XP logic unchanged.
- Flutter build/analyze not run in this environment.
