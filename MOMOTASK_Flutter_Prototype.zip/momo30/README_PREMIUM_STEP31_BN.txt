MOMOTASK PREMIUM STEP 31

এই ধাপে Admin XP Add/Remove-এর আগে Firestore থেকে XP-এর দুইটি ledger নতুন করে পড়া হয়:
- xp_earnings-এর সব XP
- xp_adjustments-এর সব positive/negative adjustment

তারপর নতুন adjustment যোগ করলে মোট XP শূন্যের নিচে যাবে কি না যাচাই করা হয়।
Positive adjustment-এর Message ঐচ্ছিক; ফাঁকা হলে reason হিসেবে empty string পাঠানো হয়।
Negative adjustment-এর Reason বাধ্যতামূলক।

গুরুত্বপূর্ণ সীমাবদ্ধতা:
এই যাচাই অ্যাপের কোডে করা। এটি server-side atomic guarantee নয়; একই সময়ে একাধিক Admin write করলে race condition হতে পারে। সম্পূর্ণ server-side enforcement-এর জন্য trusted Cloud Function/backend transaction প্রয়োজন।

Flutter SDK এই পরিবেশে চালানো হয়নি। তাই flutter analyze বা APK build সফল হয়েছে—এমন দাবি করা হচ্ছে না।
