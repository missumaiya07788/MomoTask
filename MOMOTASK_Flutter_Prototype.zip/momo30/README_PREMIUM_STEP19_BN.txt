MOMOTASK PREMIUM UI - STEP 19

এই ধাপে Student-এর Active Mission List ও 3-month archive retention যুক্ত করা হয়েছে।
- Student Dashboard-এ সর্বশেষ ১০টি non-archived mission দেখানো হয়।
- নতুন mission যোগ হলে ১০টির বেশি active mission থাকলে পুরোনোগুলো archived=true হয়।
- Profile-এ সব mission পাঠানো হয়, তাই archived mission-ও Calendar history-তে থাকতে পারে।
- Admin app চালু হলে এবং নতুন mission তৈরি হলে ৩ মাসের বেশি পুরোনো mission delete করার cleanup চলে।

গুরুত্বপূর্ণ সীমাবদ্ধতা:
- এটি scheduled server-side cleanup নয়। Admin app খোলা বা নতুন mission তৈরি হওয়ার সময় cleanup হয়; Admin app দীর্ঘদিন না খুললে মেয়াদোত্তীর্ণ record তখনই মুছবে না।
- Firestore Rules-এ admin-কে mission update/delete করার অনুমতি থাকতে হবে। বর্তমান Rules-এ isAdmin() update/delete অনুমোদন করলে কাজ করবে।
- Flutter SDK দিয়ে analyze/build ও দুই APK-তে পরীক্ষা করা হয়নি। Firebase retention flow-ও live project-এ যাচাই করা হয়নি।
