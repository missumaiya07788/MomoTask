MOMOTASK Premium UI – Step 16

Admin Approval / Review Card polish:
- Each pending submission now shows a short, two-line task-instruction preview beneath its title.
- Long instructions are safely truncated in the card; the existing review and Approve action remains unchanged.
- Existing Firebase callbacks, mission status flow, XP handling, and role routing were not edited in this step.

Validation:
- ZIP archive integrity checked after packaging.
- Flutter SDK is not available in this environment; flutter analyze and Android builds were not run.
