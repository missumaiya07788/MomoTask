MOMOTASK PREMIUM UI - STEP 20

এই ধাপে Archive ও Profile Calendar-এর নির্ভরযোগ্যতা উন্নত করা হয়েছে:
1. Profile Calendar-এ শুধু চলতি মাস ও আগের দুই মাসের Task দেখানো হয়।
2. তিন মাসের আগের Task ভুলবশত Calendar-এ দেখা যায় না, Admin cleanup চলার আগেও।
3. Firebase history cleanup ৪৫০টি write করে batch commit করে; ফলে Firestore-এর ৫০০ write সীমা অতিক্রমের ঝুঁকি কমে।
4. Profile-এর মোট XP ও progress গণনা সব সংরক্ষিত mission থেকেই হয়; Calendar-এর ৩ মাসের সীমা progress-কে সীমাবদ্ধ করে না।

গুরুত্বপূর্ণ:
- Cleanup এখনো Admin APK চালু হলে / নতুন Task তৈরি হলে চলে।
- নির্দিষ্ট সময়ে সার্ভার থেকে স্বয়ংক্রিয় deletion-এর জন্য পরে Firebase TTL বা Scheduled Function configure করতে হবে।
- Flutter SDK এই পরিবেশে নেই, তাই flutter analyze/build চালানো যায়নি।
- ZIP integrity পরীক্ষা করা হয়েছে; Firebase rules ও live device sync আলাদাভাবে যাচাই করতে হবে।
