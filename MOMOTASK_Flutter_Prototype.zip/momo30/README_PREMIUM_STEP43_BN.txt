MOMOTASK Premium UI - Step43

এই ধাপে Student Profile-এর XP Notifications-এ Approved Mission-এর XP-ও দেখানো হয়।

- Admin কোনো Submitted Mission Approve করলে xp_earnings ledger-এ missionTitle এবং notificationType সংরক্ষণ হয়।
- Student Profile-এর XP Notifications এখন xp_adjustments এবং xp_earnings—দুই collection থেকেই তথ্য দেখায়।
- Mission-এর নাম, অর্জিত XP এবং সংরক্ষিত timestamp দেখানো হয়।
- xp_earnings-এর deterministic mission document ID আগের মতোই duplicate XP record প্রতিরোধে ব্যবহৃত হয়।
- Premium UI-এর মূল design language অপরিবর্তিত।

গুরুত্বপূর্ণ:
- Firestore Rules-এ xp_earnings-এর read permission Student-এর নিজের studentUid-তে সীমাবদ্ধ থাকা প্রয়োজন। বর্তমান project rules-এ এই অনুমতি থাকলে অতিরিক্ত পরিবর্তন দরকার নেই।
- পুরোনো xp_earnings record-এ missionTitle না থাকলে 'Mission completed' দেখাবে। নতুন approval-এ missionTitle সংরক্ষিত হবে।
- Flutter SDK এখানে উপলব্ধ না থাকায় flutter analyze, build বা APK runtime test করা হয়নি। ZIP integrity check করা হয়েছে।
