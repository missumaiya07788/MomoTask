MOMOTASK Premium UI - Step 13

Student Mission Details-এর Submit task button এখন scrollable instruction অংশের বাইরে নিচে স্থির থাকে। ফলে বড় Description পড়তে স্ক্রল করলেও Submit button সহজে পাওয়া যাবে।

পরিবর্তনটি শুধু lib/widgets/mission_card.dart-এর Mission Details layout-এ করা হয়েছে। Firebase, Mission model, save/sync, approval ও XP logic স্পর্শ করা হয়নি।

সতর্কতা: এই পরিবেশে Flutter/Dart SDK নেই, তাই flutter analyze/build চালানো যায়নি। ZIP integrity পরীক্ষা করা হয়েছে; এটি build-tested APK নয়।
