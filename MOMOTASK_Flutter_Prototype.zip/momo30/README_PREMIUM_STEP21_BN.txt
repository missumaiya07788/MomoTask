MOMOTASK PREMIUM UI — STEP 21

পরিবর্তন:
- Task history retention ৩ মাস থেকে ১ মাস করা হয়েছে।
- Admin-এর history cleanup এখন ১ মাসের বেশি পুরোনো mission মুছে দেয়।
- Student Profile Calendar শুধু চলতি মাসের Task দেখায়।
- সর্বশেষ ১০টি Active Task-এর নিয়ম অপরিবর্তিত।

গুরুত্বপূর্ণ:
- Cleanup Admin APK চালু হলে/নতুন Task তৈরি হলে চলে; নির্দিষ্ট সময়ে স্বয়ংক্রিয় cleanup নয়।
- Flutter analyze/build এবং Firebase বাস্তব পরীক্ষা এই পরিবেশে করা হয়নি।
- Firestore Rules-এ Admin-এর delete permission না থাকলে cleanup ব্যর্থ হতে পারে।
