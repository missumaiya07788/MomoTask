import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../models/mission.dart';
import 'admin_screen.dart';
import 'student_screen.dart';

class AppShell extends StatefulWidget {
  final String role;
  const AppShell({super.key, required this.role});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  final _missions = FirebaseFirestore.instance.collection('missions');
  final _xpAdjustments = FirebaseFirestore.instance.collection('xp_adjustments');
  final _xpEarnings = FirebaseFirestore.instance.collection('xp_earnings');
  // Sumaiya's student account in this MOMOTASK Firebase project.
  static const _studentUid = 'YdkD6EkUO0PxPJtcgK1PlbopDC32';
  bool _retentionChecked = false;
  bool _xpAdjustmentInProgress = false;

  Mission _fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data() ?? {};
    final rawStatus = data['status'] as String? ?? 'available';
    final status = MissionStatus.values.firstWhere(
      (value) => value.name == rawStatus,
      orElse: () => MissionStatus.available,
    );
    return Mission(
      id: doc.id,
      title: data['title'] as String? ?? 'Untitled mission',
      description: data['description'] as String? ?? '',
      points: (data['points'] as num?)?.toInt() ?? 0,
      category: data['category'] as String? ?? 'Study',
      dueLabel: data['dueLabel'] as String? ?? 'Today',
      status: status,
      createdBy: data['createdBy'] as String? ?? 'admin',
      createdAt: (data['createdAt'] as Timestamp?)?.toDate(),
      submittedAt: (data['submittedAt'] as Timestamp?)?.toDate(),
      approvedAt: (data['approvedAt'] as Timestamp?)?.toDate(),
      archived: data['archived'] as bool? ?? false,
    );
  }

  Future<void> _addMission(Mission mission) async {
    await _missions.doc(mission.id).set({
      'title': mission.title,
      'description': mission.description,
      'points': mission.points,
      'category': mission.category,
      'dueLabel': mission.dueLabel,
      'status': MissionStatus.available.name,
      'createdBy': FirebaseAuth.instance.currentUser?.uid ?? 'admin',
      'createdAt': FieldValue.serverTimestamp(),
      'archived': false,
    });
    await _maintainTaskHistory();
  }

  DateTime _oneMonthAgo(DateTime date) {
    final previousMonth = DateTime(date.year, date.month - 1, 1);
    final lastDay = DateTime(previousMonth.year, previousMonth.month + 1, 0).day;
    return DateTime(previousMonth.year, previousMonth.month,
        date.day > lastDay ? lastDay : date.day);
  }

  Future<void> _backfillApprovedMissionEarnings(
      QuerySnapshot<Map<String, dynamic>> snapshot) async {
    // Before retention cleanup, preserve XP from every still-existing approved
    // mission. Deterministic IDs make this safe to run repeatedly.
    for (final doc in snapshot.docs) {
      final data = doc.data();
      if (data['status'] != MissionStatus.approved.name) continue;
      final earningRef = _xpEarnings.doc(doc.id);
      await FirebaseFirestore.instance.runTransaction((transaction) async {
        final existing = await transaction.get(earningRef);
        if (existing.exists) return;
        transaction.set(earningRef, {
          'studentUid': _studentUid,
          'missionId': doc.id,
          'xp': (data['points'] as num?)?.toInt() ?? 0,
          'createdAt': data['approvedAt'] is Timestamp
              ? data['approvedAt']
              : (data['createdAt'] is Timestamp
                  ? data['createdAt']
                  : FieldValue.serverTimestamp()),
          'createdBy': FirebaseAuth.instance.currentUser?.uid ?? '',
          'backfilled': true,
        });
      });
    }
  }

  Future<void> _maintainTaskHistory() async {
    // Preserve approved XP before any expired mission can be deleted.
    final beforeCleanup = await _missions.orderBy('createdAt', descending: true).get();
    await _backfillApprovedMissionEarnings(beforeCleanup);
    // Keep the newest 10 missions active; older missions remain available
    // to the student's 1-month profile calendar as archived records.
    final snapshot = await _missions.orderBy('createdAt', descending: true).get();
    final cutoff = DateTime.now();
    final expiry = _oneMonthAgo(cutoff);
    // Firestore batches are limited to 500 writes. Commit in smaller chunks
    // so a large history can be maintained without exceeding that limit.
    var batch = FirebaseFirestore.instance.batch();
    var writes = 0;
    var activeCount = 0;
    Future<void> commitIfNeeded({bool force = false}) async {
      if (writes >= 450 || (force && writes > 0)) {
        await batch.commit();
        batch = FirebaseFirestore.instance.batch();
        writes = 0;
      }
    }

    for (final doc in snapshot.docs) {
      final data = doc.data();
      final createdAt = (data['createdAt'] as Timestamp?)?.toDate();
      if (createdAt != null && createdAt.isBefore(expiry)) {
        batch.delete(doc.reference);
        writes++;
      } else {
        final archived = data['archived'] as bool? ?? false;
        if (!archived) {
          activeCount++;
          if (activeCount > 10) {
            batch.update(doc.reference, {
              'archived': true,
              'archivedAt': FieldValue.serverTimestamp(),
            });
            writes++;
          }
        }
      }
      await commitIfNeeded();
    }
    await commitIfNeeded(force: true);
  }

  Future<void> _adjustStudentXp(int delta, String message) async {
    if (widget.role != 'admin') throw StateError('Only Admin can adjust XP.');
    if (_xpAdjustmentInProgress) {
      throw StateError('An XP update is already being processed. Please wait.');
    }
    _xpAdjustmentInProgress = true;
    try {
    if (delta == 0) throw ArgumentError('XP change cannot be zero.');
    final text = message.trim();
    if (delta < 0 && text.isEmpty) {
      throw ArgumentError('A reason is required when reducing XP.');
    }

    // Create the ledger reference once, outside the transaction. Firestore may
    // retry the transaction internally; every retry therefore targets the same
    // immutable adjustment document instead of creating another record.
    final adjustmentRef = _xpAdjustments.doc();
    final firestore = FirebaseFirestore.instance;
    final adminUid = FirebaseAuth.instance.currentUser?.uid;
    if (adminUid == null || adminUid.isEmpty) {
      throw StateError('Admin session has expired. Please sign in again.');
    }

    // Query collections directly: Firestore transactions in this plugin
    // version read document references, not collection queries.
    final earningsSnapshot = await _xpEarnings
        .where('studentUid', isEqualTo: _studentUid)
        .get();
    final adjustmentsSnapshot = await _xpAdjustments
        .where('studentUid', isEqualTo: _studentUid)
        .get();
    final missionXp = earningsSnapshot.docs.fold<int>(
      0,
      (total, doc) => total + ((doc.data()['xp'] as num?)?.toInt() ?? 0),
    );
    final adjustmentXp = adjustmentsSnapshot.docs.fold<int>(
      0,
      (total, doc) => total + ((doc.data()['xpDelta'] as num?)?.toInt() ?? 0),
    );
    final currentXp = missionXp + adjustmentXp;
    if (currentXp + delta < 0) {
      throw StateError('XP cannot go below zero. Current balance: $currentXp XP.');
    }

    await firestore.runTransaction((transaction) async {
      transaction.set(adjustmentRef, {
        'studentUid': _studentUid,
        'xpDelta': delta,
        // Firestore Rules require a string even when an add message is omitted.
        'reason': text,
        'createdAt': FieldValue.serverTimestamp(),
        'createdBy': adminUid,
        'operationId': adjustmentRef.id,
      });
    });
    } finally {
      _xpAdjustmentInProgress = false;
    }
  }

  Future<void> _deleteMission(Mission mission) async {
    if (widget.role != 'admin') {
      throw StateError('Only Admin can delete missions.');
    }
    await _missions.doc(mission.id).delete();
  }

  Future<void> _submitMission(Mission mission) async {
    // Use a transaction so rapid/repeated taps cannot submit the same
    // mission more than once. Only an available mission may be submitted.
    final missionRef = _missions.doc(mission.id);
    await FirebaseFirestore.instance.runTransaction((transaction) async {
      final snapshot = await transaction.get(missionRef);
      if (!snapshot.exists) {
        throw StateError('This mission is no longer available.');
      }
      final data = snapshot.data() ?? <String, dynamic>{};
      if (data['status'] != MissionStatus.available.name) {
        // Another tap/request already submitted or completed this mission.
        return;
      }
      transaction.update(missionRef, {
        'status': MissionStatus.submitted.name,
        'submittedAt': FieldValue.serverTimestamp(),
      });
    });
  }

  Future<void> _approveMission(Mission mission) async {
    final firestore = FirebaseFirestore.instance;
    final missionRef = _missions.doc(mission.id);
    // A deterministic ledger document prevents duplicate XP if approval is tapped twice.
    final earningRef = _xpEarnings.doc(mission.id);
    await firestore.runTransaction((transaction) async {
      final missionSnapshot = await transaction.get(missionRef);
      if (!missionSnapshot.exists) throw StateError('Mission no longer exists.');
      final data = missionSnapshot.data() ?? <String, dynamic>{};
      if (data['status'] == MissionStatus.approved.name) return;
      if (data['status'] != MissionStatus.submitted.name) {
        throw StateError('Only submitted missions can be approved.');
      }
      // Read the deterministic XP ledger inside the same transaction. If a
      // ledger entry already exists, do not create another XP award.
      final existingEarning = await transaction.get(earningRef);
      transaction.update(missionRef, {
        'status': MissionStatus.approved.name,
        'approvedAt': FieldValue.serverTimestamp(),
      });
      if (!existingEarning.exists) transaction.set(earningRef, {
        'studentUid': _studentUid,
        'missionId': mission.id,
        'missionTitle': mission.title,
        'xp': (data['points'] as num?)?.toInt() ?? mission.points,
        'notificationType': 'mission_approved',
        'createdAt': FieldValue.serverTimestamp(),
        'createdBy': FirebaseAuth.instance.currentUser?.uid ?? '',
      });
    });
  }

  Future<void> _logout() async => FirebaseAuth.instance.signOut();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: _missions.orderBy('createdAt', descending: true).snapshots(),
      builder: (context, snapshot) {
        if (widget.role == 'admin' && snapshot.hasData && !_retentionChecked) {
          _retentionChecked = true;
          WidgetsBinding.instance.addPostFrameCallback((_) {
            _maintainTaskHistory().catchError((_) {});
          });
        }
        if (snapshot.hasError) {
          return Scaffold(body: Center(child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text('Could not load missions. Check Firestore access and internet connection.\n\n${snapshot.error}', textAlign: TextAlign.center),
          )));
        }
        if (!snapshot.hasData) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        final missions = snapshot.data!.docs.map(_fromDoc).toList();
        return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: _xpAdjustments.where('studentUid', isEqualTo: _studentUid).snapshots(),
          builder: (context, xpSnapshot) {
            return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: _xpEarnings.where('studentUid', isEqualTo: _studentUid).snapshots(),
              builder: (context, earningsSnapshot) {
            final missionXp = earningsSnapshot.data?.docs.fold<int>(0, (total, doc) => total + ((doc.data()['xp'] as num?)?.toInt() ?? 0)) ?? 0;
            final adjustmentXp = xpSnapshot.data?.docs.fold<int>(0, (total, doc) => total + ((doc.data()['xpDelta'] as num?)?.toInt() ?? 0)) ?? 0;
            final xp = missionXp + adjustmentXp;
        final now = DateTime.now();
        final today = DateTime(now.year, now.month, now.day);
        final weekStart = today.subtract(Duration(days: today.weekday - 1));
        final weeklyXp = List<int>.filled(7, 0);
        final weeklyTasks = List<int>.filled(7, 0);
        for (final doc in earningsSnapshot.data?.docs ?? []) {
          final data = doc.data();
          final stamp = data['createdAt'];
          if (stamp is Timestamp) {
            final earnedAt = stamp.toDate();
            final earnedDay = DateTime(earnedAt.year, earnedAt.month, earnedAt.day);
            final dayIndex = earnedDay.difference(weekStart).inDays;
            if (dayIndex >= 0 && dayIndex < 7) {
              weeklyXp[dayIndex] += (data['xp'] as num?)?.toInt() ?? 0;
              weeklyTasks[dayIndex] += 1;
            }
          }
        }
        if (widget.role == 'admin') {
          return AdminScreen(missions: missions, onAddMission: _addMission,
              onApprove: _approveMission, onDeleteMission: _deleteMission, onAdjustXp: _adjustStudentXp, totalStudentXp: xp, onLogout: _logout);
        }
        final activeMissions = missions.where((mission) => !mission.archived).take(10).toList();
        return StudentScreen(missions: activeMissions, allMissions: missions, xp: xp, missionXp: missionXp, adjustmentXp: adjustmentXp, weeklyXp: weeklyXp, weeklyTasks: weeklyTasks, onSubmit: _submitMission,
            onSwitchRole: () {}, onLogout: _logout);
              },
            );
          },
        );
      },
    );
  }
}
