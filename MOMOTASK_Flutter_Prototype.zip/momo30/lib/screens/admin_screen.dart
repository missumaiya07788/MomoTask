import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/mission.dart';
import '../widgets/mission_card.dart';

const _ink = Color(0xFFF5F2FF);
const _muted = Color(0xFFA7A2BD);
const _purple = Color(0xFF9A83FF);
const _canvas = Color(0xFF11101B);
const _panel = Color(0xFF211F32);
const _line = Color(0xFF343149);

class AdminScreen extends StatelessWidget {
  const AdminScreen({super.key, required this.missions, required this.onAddMission, required this.onApprove, required this.onDeleteMission, required this.onAdjustXp, required this.totalStudentXp, required this.onLogout});

  final List<Mission> missions;
  final ValueChanged<Mission> onAddMission;
  final ValueChanged<Mission> onApprove;
  final Future<void> Function(Mission) onDeleteMission;
  final Future<void> Function(int, String) onAdjustXp;
  final int totalStudentXp;
  final VoidCallback onLogout;

  Widget _xpAdjustmentHistory() {
    const studentUid = 'YdkD6EkUO0PxPJtcgK1PlbopDC32';
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection('xp_adjustments')
          .where('studentUid', isEqualTo: studentUid)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return const Text('Could not load XP history. Check Firestore Rules.',
              style: TextStyle(color: _muted, fontSize: 12));
        }
        if (!snapshot.hasData) {
          return const Padding(
            padding: EdgeInsets.all(12),
            child: Center(child: CircularProgressIndicator()),
          );
        }
        final docs = [...snapshot.data!.docs];
        docs.sort((a, b) {
          final aTime = a.data()['createdAt'];
          final bTime = b.data()['createdAt'];
          final aDate = aTime is Timestamp ? aTime.toDate() : DateTime.fromMillisecondsSinceEpoch(0);
          final bDate = bTime is Timestamp ? bTime.toDate() : DateTime.fromMillisecondsSinceEpoch(0);
          return bDate.compareTo(aDate);
        });
        final recent = docs.take(10).toList();
        return Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: _panel,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: _line),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                const Expanded(child: Text('XP adjustment history', style: TextStyle(color: _ink, fontWeight: FontWeight.w900, fontSize: 15))),
                Text('${docs.length} RECORDS', style: const TextStyle(color: _muted, fontSize: 9, fontWeight: FontWeight.w800)),
              ]),
              const SizedBox(height: 10),
              if (recent.isEmpty)
                const Text('No manual XP changes yet.', style: TextStyle(color: _muted, fontSize: 12))
              else
                ...recent.map((doc) {
                  final data = doc.data();
                  final delta = (data['xpDelta'] as num?)?.toInt() ?? 0;
                  final reason = (data['reason'] as String?)?.trim() ?? '';
                  final stamp = data['createdAt'];
                  final date = stamp is Timestamp ? stamp.toDate() : null;
                  final dateLabel = date == null
                      ? 'Time pending'
                      : '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}  ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
                  return Padding(
                    padding: const EdgeInsets.only(top: 9),
                    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Icon(delta < 0 ? Icons.remove_circle_outline : Icons.add_circle_outline,
                          color: delta < 0 ? const Color(0xFFFF8B8B) : const Color(0xFF79D9B0), size: 20),
                      const SizedBox(width: 9),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('${delta > 0 ? '+' : ''}$delta XP', style: TextStyle(color: delta < 0 ? const Color(0xFFFF8B8B) : const Color(0xFF79D9B0), fontWeight: FontWeight.w900)),
                        if (reason.isNotEmpty) Text(reason, style: const TextStyle(color: _ink, fontSize: 12)),
                        Text(dateLabel, style: const TextStyle(color: _muted, fontSize: 10)),
                      ])),
                    ]),
                  );
                }),
            ],
          ),
        );
      },
    );
  }

  Future<void> _manageXp(BuildContext context) async {
    final amount = TextEditingController(text: '10');
    final message = TextEditingController();
    var increase = true;
    final formKey = GlobalKey<FormState>();
    final result = await showDialog<bool>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setDialogState) => AlertDialog(
      backgroundColor: _panel,
      title: const Text('Manage Sumaiya XP', style: TextStyle(color: _ink, fontWeight: FontWeight.w900)),
      content: Form(key: formKey, child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text('Current total: $totalStudentXp XP', style: const TextStyle(color: _purple, fontWeight: FontWeight.w800)),
        const SizedBox(height: 14),
        SegmentedButton<bool>(segments: const [ButtonSegment(value: true, label: Text('Add XP'), icon: Icon(Icons.add_rounded)), ButtonSegment(value: false, label: Text('Remove XP'), icon: Icon(Icons.remove_rounded))], selected: {increase}, onSelectionChanged: (v) => setDialogState(() => increase = v.first)),
        const SizedBox(height: 14),
        TextFormField(controller: amount, keyboardType: TextInputType.number, style: const TextStyle(color: _ink), decoration: const InputDecoration(labelText: 'XP amount', labelStyle: TextStyle(color: _muted)), validator: (v) { final n = int.tryParse(v ?? ''); if (n == null || n <= 0) return 'Enter a number greater than zero'; if (!increase && n > totalStudentXp) return 'Cannot remove more than the current XP balance'; return null; }),
        TextFormField(controller: message, maxLines: 3, style: const TextStyle(color: _ink), decoration: InputDecoration(labelText: increase ? 'Message (optional)' : 'Reason (required)', labelStyle: const TextStyle(color: _muted)), validator: (v) => !increase && (v == null || v.trim().isEmpty) ? 'Reason is required' : null),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')), FilledButton(onPressed: () { if (formKey.currentState!.validate()) Navigator.pop(ctx, true); }, child: const Text('Confirm'))],
    )));
    if (result == true) {
      final n = int.parse(amount.text.trim());
      try {
        await onAdjustXp(increase ? n : -n, message.text.trim());
        if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('XP updated successfully.')));
      } catch (e) {
        if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not update XP: $e')));
      }
    }
    amount.dispose(); message.dispose();
  }

  Future<void> _createMission(BuildContext context, {String? presetTitle, String? presetCategory}) async {
    final title = TextEditingController(text: presetTitle ?? '');
    final details = TextEditingController();
    final points = TextEditingController(text: '10');
    final formKey = GlobalKey<FormState>();
    final result = await showDialog<bool>(context: context, builder: (ctx) => Dialog(
      insetPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 24),
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.fromLTRB(21, 21, 21, 17),
        decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(26), border: Border.all(color: _line), boxShadow: [BoxShadow(color: _ink.withOpacity(.12), blurRadius: 28, offset: const Offset(0, 12))]),
        child: SafeArea(child: Form(key: formKey, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Container(width: 42, height: 42, decoration: BoxDecoration(color: const Color(0xFF342C55), borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.auto_awesome_rounded, color: _purple)), const SizedBox(width: 12), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Create a mission', style: TextStyle(color: _ink, fontSize: 19, fontWeight: FontWeight.w900)), SizedBox(height: 3), Text('Make the next study win count.', style: TextStyle(color: _muted, fontSize: 11))]))]),
          const SizedBox(height: 21),
          _missionField(title, 'Mission title', Icons.flag_outlined, validator: (v) => (v == null || v.trim().isEmpty) ? 'Add a title' : null),
          const SizedBox(height: 12),
          _missionField(details, 'Instructions (optional)', Icons.notes_rounded, maxLines: 3),
          const SizedBox(height: 12),
          _missionField(points, 'XP points', Icons.bolt_rounded, keyboardType: TextInputType.number, validator: (v) { final value = int.tryParse(v ?? ''); return value == null || value < 1 ? 'Enter at least 1 XP' : null; }),
          const SizedBox(height: 20),
          Row(children: [Expanded(child: OutlinedButton(onPressed: () => Navigator.pop(ctx, false), style: OutlinedButton.styleFrom(foregroundColor: _muted, side: const BorderSide(color: _line), padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))), child: const Text('Cancel'))), const SizedBox(width: 10), Expanded(child: FilledButton(onPressed: () { if (formKey.currentState!.validate()) Navigator.pop(ctx, true); }, style: FilledButton.styleFrom(backgroundColor: _purple, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))), child: const Text('Create mission', style: TextStyle(fontWeight: FontWeight.w800))))]),
        ])))),
      ),
    ));
    if (result == true) onAddMission(Mission(id: DateTime.now().microsecondsSinceEpoch.toString(), title: title.text.trim(), description: details.text.trim().isEmpty ? 'Complete this study mission.' : details.text.trim(), points: int.parse(points.text), category: presetCategory ?? 'Study', dueLabel: 'Today'));
    title.dispose(); details.dispose(); points.dispose();
  }

  static Widget _missionField(TextEditingController controller, String label, IconData icon, {int maxLines = 1, TextInputType? keyboardType, String? Function(String?)? validator}) => TextFormField(
    controller: controller,
    maxLines: maxLines,
    keyboardType: keyboardType,
    validator: validator,
    style: const TextStyle(color: _ink, fontSize: 13, fontWeight: FontWeight.w600),
    decoration: InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: _muted, fontSize: 12),
      prefixIcon: Icon(icon, color: _purple, size: 19),
      alignLabelWithHint: maxLines > 1,
      filled: true,
      fillColor: const Color(0xFF2B2741),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: _line)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: _purple, width: 1.4)),
      errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: Color(0xFFE16B75))),
    ),
  );

  Future<void> _previewTemplate(BuildContext context, {required String title, required String emoji, required String subtitle, required Color color, required String presetTitle, required String category}) async {
    final use = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        padding: const EdgeInsets.fromLTRB(22, 12, 22, 26),
        decoration: BoxDecoration(color: _panel, borderRadius: const BorderRadius.vertical(top: Radius.circular(30)), border: Border.all(color: _line)),
        child: SafeArea(child: ConstrainedBox(constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * .84), child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Center(child: Container(width: 42, height: 4, decoration: BoxDecoration(color: const Color(0xFF514B68), borderRadius: BorderRadius.circular(8)))),
          const SizedBox(height: 18),
          const Text('TEMPLATE PREVIEW', style: TextStyle(color: _purple, fontSize: 10, letterSpacing: 1.5, fontWeight: FontWeight.w900)),
          const SizedBox(height: 12),
          Container(
            height: 156,
            width: double.infinity,
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [color, color.withOpacity(.55)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(24),
              boxShadow: [BoxShadow(color: color.withOpacity(.32), blurRadius: 18, offset: const Offset(0, 8))],
            ),
            child: Stack(alignment: Alignment.center, children: [
              Positioned(right: -28, top: -42, child: Container(width: 150, height: 150, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.white.withOpacity(.22), width: 18)))),
              Positioned(left: -30, bottom: -65, child: Container(width: 145, height: 145, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(.10)))),
              Positioned(top: 13, left: 15, child: Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: Colors.black.withOpacity(.13), borderRadius: BorderRadius.circular(30), border: Border.all(color: Colors.white.withOpacity(.22))), child: const Text('MOMOTASK • ORIGINAL THEME', style: TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: 1.0)))),
              Positioned(bottom: 13, right: 15, child: Icon(_previewIcon(title), color: Colors.white.withOpacity(.35), size: 35)),
              Text(emoji, style: const TextStyle(fontSize: 66, shadows: [Shadow(color: Colors.black26, blurRadius: 16, offset: Offset(0, 5))])),
            ]),
          ),
          const SizedBox(height: 18),
          Text(title, style: const TextStyle(color: _ink, fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          Text(subtitle, style: const TextStyle(color: _muted, fontSize: 13, height: 1.45)),
          const SizedBox(height: 17),
          Container(width: double.infinity, padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: const Color(0xFF2B2741), borderRadius: BorderRadius.circular(17)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('SUGGESTED MISSION', style: TextStyle(color: _muted, fontSize: 9, letterSpacing: 1.2, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6), Text(presetTitle, style: const TextStyle(color: _ink, fontSize: 15, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4), Text('$category · You can edit title, instructions and XP next', style: const TextStyle(color: _muted, fontSize: 11)),
          ])),
          const SizedBox(height: 18),
          Row(children: [Expanded(child: OutlinedButton(onPressed: () => Navigator.pop(ctx, false), style: OutlinedButton.styleFrom(foregroundColor: _muted, side: const BorderSide(color: _line), padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))), child: const Text('Not now'))), const SizedBox(width: 10), Expanded(child: FilledButton.icon(onPressed: () => Navigator.pop(ctx, true), icon: const Icon(Icons.arrow_forward_rounded, size: 17), label: const Text('Use template'), style: FilledButton.styleFrom(backgroundColor: _purple, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)), textStyle: const TextStyle(fontWeight: FontWeight.w800))))]),
        ])))),
      ),
    );
    if (use == true && context.mounted) {
      await _createMission(context, presetTitle: presetTitle, presetCategory: category);
    }
  }

  @override
  Widget build(BuildContext context) {
    final pending = missions.where((m) => m.status == MissionStatus.submitted).toList();
    final active = missions.where((m) => m.status == MissionStatus.available).length;
    final completed = missions.where((m) => m.status == MissionStatus.approved).length;
    return Scaffold(backgroundColor: _canvas, body: SafeArea(child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 720), child: ListView(padding: const EdgeInsets.fromLTRB(18, 12, 18, 28), children: [
      Row(children: [Container(width: 46, height: 46, decoration: BoxDecoration(color: _ink, borderRadius: BorderRadius.circular(15)), child: const Icon(Icons.bolt_rounded, color: Color(0xFFFFC96B), size: 27)), const SizedBox(width: 12), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('MOMOTASK ADMIN', style: TextStyle(color: _ink, fontWeight: FontWeight.w900, letterSpacing: 1.1, fontSize: 16)), Text('Your mission control', style: TextStyle(color: _muted, fontSize: 12))])), IconButton(onPressed: onLogout, icon: const Icon(Icons.logout_rounded, color: _ink))]),
      const SizedBox(height: 22),
      Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF262044), Color(0xFF5540A8)]), borderRadius: BorderRadius.circular(26), boxShadow: [BoxShadow(color: _purple.withOpacity(.18), blurRadius: 22, offset: const Offset(0, 10))]), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [const Expanded(child: Text('ADMIN STUDIO', style: TextStyle(color: Color(0xFFC9C0FF), letterSpacing: 1.6, fontSize: 11, fontWeight: FontWeight.w800))), Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: Colors.white.withOpacity(.12), borderRadius: BorderRadius.circular(30)), child: const Text('LIVE BOARD', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700)))]),
        const SizedBox(height: 15), const Text('Build her next\nbig study win.', style: TextStyle(color: Colors.white, fontSize: 27, height: 1.12, fontWeight: FontWeight.w900)), const SizedBox(height: 8), const Text('Small missions. Real progress. Lovely rewards.', style: TextStyle(color: Color(0xFFD8D2F5), fontSize: 12)), const SizedBox(height: 20),
        LayoutBuilder(builder: (context, constraints) {
          const gap = 8.0;
          final columns = constraints.maxWidth < 330 ? 1 : 3;
          final itemWidth = (constraints.maxWidth - gap * (columns - 1)) / columns;
          return Wrap(
            spacing: gap,
            runSpacing: gap,
            children: [
              SizedBox(width: itemWidth, child: _heroStat('ACTIVE', '$active', Icons.bolt_rounded)),
              SizedBox(width: itemWidth, child: _heroStat('TO REVIEW', '${pending.length}', Icons.fact_check_outlined)),
              SizedBox(width: itemWidth, child: _heroStat('DONE', '$completed', Icons.check_circle_outline)),
            ],
          );
        }),
      ])),
      const SizedBox(height: 18),
      Container(padding: const EdgeInsets.all(17), decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(20), border: Border.all(color: _line)), child: Row(children: [const Icon(Icons.stars_rounded, color: Color(0xFFFFD37D), size: 28), const SizedBox(width: 11), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text("SUMAIYA'S XP BALANCE", style: TextStyle(color: _muted, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: .8)), Text('$totalStudentXp XP', style: const TextStyle(color: _ink, fontSize: 21, fontWeight: FontWeight.w900))])), FilledButton.icon(onPressed: () => _manageXp(context), icon: const Icon(Icons.tune_rounded, size: 16), label: const Text('Manage XP'), style: FilledButton.styleFrom(backgroundColor: _purple, foregroundColor: Colors.white))])),
      const SizedBox(height: 12),
      _xpAdjustmentHistory(),
      const SizedBox(height: 25),
      Row(children: [const Expanded(child: Text('Quick create', style: TextStyle(color: _ink, fontWeight: FontWeight.w900, fontSize: 19))), FilledButton.icon(onPressed: () => _createMission(context), icon: const Icon(Icons.add_rounded, size: 17), label: const Text('New mission'), style: FilledButton.styleFrom(backgroundColor: _purple, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))))]),
      const SizedBox(height: 9),
      const Padding(padding: EdgeInsets.only(bottom: 10), child: Text('Choose a style, preview it, then customise your mission.', style: TextStyle(color: _muted, fontSize: 11, height: 1.4))),
      SizedBox(height: 164, child: ListView(scrollDirection: Axis.horizontal, physics: const BouncingScrollPhysics(), children: [
        _template('Minimal', '✦', const Color(0xFFECE8FF), 'Clean and calm study missions', () => _previewTemplate(context, title: 'Minimal & Aesthetic', emoji: '✦', subtitle: 'A quiet, distraction-free look for focused study sessions.', color: const Color(0xFFECE8FF), presetTitle: 'Focused study session', category: 'Study')),
        _template('Robotic', '🤖', const Color(0xFFDDF6F1), 'Futuristic challenge style', () => _previewTemplate(context, title: 'Robotic / Sci-Fi', emoji: '🤖', subtitle: 'A futuristic mission look for ambitious study challenges.', color: const Color(0xFFDDF6F1), presetTitle: 'Tech challenge', category: 'Challenge')),
        _template('Cinematic', '🎬', const Color(0xFFFFE5DF), 'Movie-inspired atmosphere', () => _previewTemplate(context, title: 'Cinematic Series', emoji: '🎬', subtitle: 'Original cinematic visuals inspired by mystery and heist moods.', color: const Color(0xFFFFE5DF), presetTitle: 'Cinematic study challenge', category: 'Challenge')),
        _template('Comedy', '🎤', const Color(0xFFFFF0D5), 'Playful comedy energy', () => _previewTemplate(context, title: 'Comedy Theme', emoji: '🎤', subtitle: 'A lively stage-inspired style for fun learning missions.', color: const Color(0xFFFFF0D5), presetTitle: 'Fun learning challenge', category: 'Fun')),
        _template('Football', '⚽', const Color(0xFFE2EEFF), 'Champion mindset', () => _previewTemplate(context, title: 'Football Legend', emoji: '⚽', subtitle: 'A stadium-inspired visual for discipline and consistency.', color: const Color(0xFFE2EEFF), presetTitle: 'Champion study sprint', category: 'Challenge')),
        _template('Momo treat', '🥟', const Color(0xFFFFE8E0), 'Food reward celebration', () => _previewTemplate(context, title: 'Food Reward', emoji: '🥟', subtitle: 'A cute reward theme for momo, kacchi, burger, pizza and more.', color: const Color(0xFFFFE8E0), presetTitle: 'Momo reward mission', category: 'Reward')),
        _template('Adventure', '🏔️', const Color(0xFFE3F2E5), 'Explore and conquer', () => _previewTemplate(context, title: 'Adventure', emoji: '🏔️', subtitle: 'Mountain and expedition-inspired challenge visuals.', color: const Color(0xFFE3F2E5), presetTitle: 'Adventure study quest', category: 'Challenge')),
        _template('Neon series', '🌌', const Color(0xFFEAE5FF), 'Neon cinematic look', () => _previewTemplate(context, title: 'Neon Series', emoji: '🌌', subtitle: 'A bold neon visual for special study missions.', color: const Color(0xFFEAE5FF), presetTitle: 'Neon focus mission', category: 'Study')),
      ])),
      const SizedBox(height: 24),
      Row(children: [Container(width: 4, height: 22, decoration: BoxDecoration(color: _purple, borderRadius: BorderRadius.circular(5))), const SizedBox(width: 9), const Expanded(child: Text('Mission board', style: TextStyle(color: _ink, fontWeight: FontWeight.w900, fontSize: 19))), Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: const Color(0xFF342C55), borderRadius: BorderRadius.circular(30)), child: Text('${missions.length} TOTAL', style: const TextStyle(color: _purple, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: .5)))]), const SizedBox(height: 10),
      if (missions.isEmpty) _empty('Your board is clear', 'Create the first mission for Sumaiya.'),
      ...missions.map((m) => Padding(padding: const EdgeInsets.only(bottom: 9), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: MissionCard(mission: m, adminMode: true)), const SizedBox(width: 7), _deleteMissionButton(context, m)]))),
      const SizedBox(height: 17),
      Row(children: [Container(width: 4, height: 22, decoration: BoxDecoration(color: const Color(0xFFE3A44B), borderRadius: BorderRadius.circular(5))), const SizedBox(width: 9), const Expanded(child: Text('Needs your review', style: TextStyle(color: _ink, fontWeight: FontWeight.w900, fontSize: 19))), if (pending.isNotEmpty) _countPill('${pending.length}')]), const SizedBox(height: 5), const Padding(padding: EdgeInsets.only(left: 13), child: Text('Check each submission before approving XP.', style: TextStyle(color: _muted, fontSize: 11))), const SizedBox(height: 10),
      if (pending.isEmpty) _empty('All caught up', 'New student submissions will appear here.'),
      ...pending.map((m) => _reviewCard(m)),
      const SizedBox(height: 14), Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFF2B2741), borderRadius: BorderRadius.circular(16)), child: const Row(children: [Icon(Icons.cloud_done_rounded, color: _purple), SizedBox(width: 10), Expanded(child: Text('Live mission data is loaded from your MOMOTASK Firebase workspace.', style: TextStyle(color: _muted, fontSize: 12, fontWeight: FontWeight.w600)))])),
    ])))));
  }


  static IconData _previewIcon(String title) {
    if (title.toLowerCase().contains('robot')) return Icons.memory_rounded;
    if (title.toLowerCase().contains('neon')) return Icons.blur_on_rounded;
    if (title.toLowerCase().contains('football')) return Icons.sports_soccer_rounded;
    if (title.toLowerCase().contains('food')) return Icons.ramen_dining_rounded;
    if (title.toLowerCase().contains('adventure')) return Icons.landscape_rounded;
    if (title.toLowerCase().contains('comedy')) return Icons.mic_rounded;
    if (title.toLowerCase().contains('cinematic')) return Icons.local_movies_rounded;
    return Icons.auto_awesome_rounded;
  }

  Widget _deleteMissionButton(BuildContext context, Mission mission) => IconButton(
    tooltip: 'Delete this task from Student app',
    onPressed: () async {
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: _panel,
          title: const Text('Delete this task?', style: TextStyle(color: _ink)),
          content: Text('"${mission.title}" will be removed from the Student app and task history. This cannot be undone.', style: const TextStyle(color: _muted)),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton.icon(onPressed: () => Navigator.pop(ctx, true), icon: const Icon(Icons.delete_outline), label: const Text('Delete'), style: FilledButton.styleFrom(backgroundColor: const Color(0xFFB94D62))),
          ],
        ),
      );
      if (confirmed == true && context.mounted) {
        try {
          await onDeleteMission(mission);
          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Task deleted from Student app and history.')),
            );
          }
        } catch (error) {
          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Could not delete task. Check Admin permission and internet.')),
            );
          }
        }
      }
    },
    icon: const Icon(Icons.delete_outline_rounded, color: Color(0xFFE47A88)),
    style: IconButton.styleFrom(backgroundColor: const Color(0xFF3A2635), minimumSize: const Size(42, 48), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13))),
  );

  Widget _reviewCard(Mission mission) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _panel,
        borderRadius: BorderRadius.circular(19),
        border: Border.all(color: const Color(0xFF59452C)),
        boxShadow: [BoxShadow(color: const Color(0xFF8A6A38).withOpacity(.075), blurRadius: 15, offset: const Offset(0, 5))],
      ),
      child: LayoutBuilder(builder: (context, constraints) {
        final narrow = constraints.maxWidth < 330;
        final details = Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(mission.title, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: _ink, fontWeight: FontWeight.w800, fontSize: 13, height: 1.25)),
            const SizedBox(height: 5),
            Text(
              mission.description,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: _muted, fontSize: 10, height: 1.35),
            ),
            const SizedBox(height: 7),
            Wrap(spacing: 7, runSpacing: 5, crossAxisAlignment: WrapCrossAlignment.center, children: [
              Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: const Color(0xFF45351F), borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFF70552F))), child: const Text('SUBMITTED', style: TextStyle(color: Color(0xFFFFD18A), fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: .6))),
              Row(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.stars_rounded, color: Color(0xFFC18B35), size: 13),
                const SizedBox(width: 4),
                Text('${mission.points} XP', style: const TextStyle(color: Color(0xFFFFD18A), fontSize: 10, fontWeight: FontWeight.w800)),
              ]),
            ]),
          ]),
        );
        final approve = FilledButton.icon(
          onPressed: () => onApprove(mission),
          icon: const Icon(Icons.check_rounded, size: 16),
          label: const Text('Approve'),
          style: FilledButton.styleFrom(backgroundColor: _purple, foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
        );
        return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(width: 42, height: 42, decoration: BoxDecoration(color: const Color(0xFF45351F), borderRadius: BorderRadius.circular(13)),
              child: const Icon(Icons.fact_check_rounded, color: Color(0xFFC18B35), size: 21)),
            const SizedBox(width: 11),
            details,
            if (!narrow) ...[const SizedBox(width: 8), approve],
          ]),
          if (narrow) Padding(padding: const EdgeInsets.only(left: 53, top: 10), child: approve),
        ]);
      }),
    );
  }

  static Widget _heroStat(String label, String value, IconData icon) => Container(padding: const EdgeInsets.all(11), decoration: BoxDecoration(color: Colors.white.withOpacity(.11), borderRadius: BorderRadius.circular(15)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: const Color(0xFFFFD37D), size: 17), const SizedBox(height: 7), Text(value, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)), Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFFD8D2F5), fontSize: 9, fontWeight: FontWeight.w700, letterSpacing: .5))]));
  static Widget _template(String title, String emoji, Color color, String subtitle, VoidCallback onTap) {
    final colors = title == 'Robotic' ? [const Color(0xFF071C2C), const Color(0xFF087E8B)]
        : title == 'Neon series' ? [const Color(0xFF170D35), const Color(0xFF7138B8)]
        : title == 'Football' ? [const Color(0xFF073B2A), const Color(0xFF27A36B)]
        : title == 'Momo treat' ? [const Color(0xFF8F302E), const Color(0xFFF29A62)]
        : title == 'Adventure' ? [const Color(0xFF193B55), const Color(0xFF6CA6A0)]
        : title == 'Comedy' ? [const Color(0xFF54234F), const Color(0xFFDB8B45)]
        : title == 'Cinematic' ? [const Color(0xFF24213A), const Color(0xFF8C3B54)]
        : [const Color(0xFFDDD5FF), const Color(0xFF7658F5)];
    final motif = title == 'Robotic' ? Icons.memory_rounded
        : title == 'Neon series' ? Icons.blur_on_rounded
        : title == 'Football' ? Icons.sports_soccer_rounded
        : title == 'Momo treat' ? Icons.ramen_dining_rounded
        : title == 'Adventure' ? Icons.landscape_rounded
        : title == 'Comedy' ? Icons.mic_rounded
        : title == 'Cinematic' ? Icons.local_movies_rounded
        : Icons.auto_awesome_rounded;
    final tag = title == 'Robotic' ? 'FUTURE MODE'
        : title == 'Neon series' ? 'AFTER DARK'
        : title == 'Football' ? 'CHAMPION MINDSET'
        : title == 'Momo treat' ? 'REWARD TIME'
        : title == 'Adventure' ? 'NEW HORIZON'
        : title == 'Comedy' ? 'HAVE SOME FUN'
        : title == 'Cinematic' ? 'SPECIAL EDITION'
        : 'FOCUS MODE';
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 178,
        margin: const EdgeInsets.only(right: 11),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: const Color(0xFF211F32),
          borderRadius: BorderRadius.circular(21),
          border: Border.all(color: const Color(0xFF39334F)),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(.18), blurRadius: 15, offset: const Offset(0, 6))],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            height: 102,
            width: double.infinity,
            decoration: BoxDecoration(
              gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: colors),
              borderRadius: BorderRadius.circular(15),
            ),
            child: Stack(clipBehavior: Clip.hardEdge, children: [
              Positioned(right: -19, top: -28, child: Container(width: 104, height: 104, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.white.withOpacity(.18), width: 13)))),
              Positioned(left: -16, bottom: -33, child: Container(width: 92, height: 92, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(.07)))),
              Positioned(left: 10, top: 9, child: Icon(motif, color: Colors.white.withOpacity(.42), size: 17)),
              Positioned(right: 12, bottom: 25, child: Icon(motif, color: Colors.white.withOpacity(.16), size: 34)),
              Positioned(left: 18, top: 34, child: Container(width: 7, height: 7, decoration: BoxDecoration(color: Colors.white.withOpacity(.42), shape: BoxShape.circle))),
              Center(child: Container(width: 66, height: 66, decoration: BoxDecoration(color: Colors.white.withOpacity(.15), shape: BoxShape.circle, border: Border.all(color: Colors.white.withOpacity(.28), width: 1.2), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.12), blurRadius: 12)]), child: Center(child: Text(emoji, style: const TextStyle(fontSize: 37))))),
              Positioned(left: 9, bottom: 8, child: Text(tag, style: TextStyle(color: Colors.white.withOpacity(.88), fontSize: 7, letterSpacing: 1.1, fontWeight: FontWeight.w900))),
              Positioned(right: 8, top: 8, child: Container(padding: const EdgeInsets.all(5), decoration: BoxDecoration(color: Colors.white.withOpacity(.15), borderRadius: BorderRadius.circular(8)), child: const Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 11))),
            ]),
          ),
          const SizedBox(height: 10),
          Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFFF5F2FF), fontWeight: FontWeight.w900, fontSize: 12)),
          const SizedBox(height: 3),
          Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFFA7A2BD), fontSize: 9, height: 1.3)),
          const SizedBox(height: 8),
          Row(children: [const Icon(Icons.touch_app_rounded, color: Color(0xFFAA98FF), size: 12), const SizedBox(width: 4), const Expanded(child: Text('TAP TO PREVIEW', style: TextStyle(color: Color(0xFFAA98FF), fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: .8))), const Icon(Icons.arrow_forward_rounded, color: Color(0xFFAA98FF), size: 13)]),
        ]),
      ),
    );
  }
  static Widget _empty(String title, String subtitle) => Container(
    width: double.infinity,
    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
    decoration: BoxDecoration(
      gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF25213B), Color(0xFF191725)]),
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: const Color(0xFF39334F)),
      boxShadow: [BoxShadow(color: _purple.withOpacity(.07), blurRadius: 16, offset: const Offset(0, 5))],
    ),
    child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
      Container(width: 48, height: 48, decoration: BoxDecoration(color: const Color(0xFF2B2741), borderRadius: BorderRadius.circular(16)), child: const Icon(Icons.auto_awesome_rounded, color: _purple, size: 23)),
      const SizedBox(width: 13),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(color: _ink, fontWeight: FontWeight.w900, fontSize: 13)),
        const SizedBox(height: 4),
        Text(subtitle, style: const TextStyle(color: _muted, fontSize: 11, height: 1.35)),
      ])),
    ]),
  );
  static Widget _countPill(String value) => Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), decoration: BoxDecoration(color: const Color(0xFFFFE9E5), borderRadius: BorderRadius.circular(30)), child: Text(value, style: const TextStyle(color: Color(0xFFC35F4F), fontWeight: FontWeight.w800)));
}

