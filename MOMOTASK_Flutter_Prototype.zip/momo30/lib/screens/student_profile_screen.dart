import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/mission.dart';

const _ink = Color(0xFFF5F2FF);
const _muted = Color(0xFFA7A2BD);
const _purple = Color(0xFF7658F5);
const _canvas = Color(0xFF11101B);

class StudentProfileScreen extends StatelessWidget {
  const StudentProfileScreen({super.key, required this.xp, required this.missionXp, required this.adjustmentXp, required this.missions});

  final int xp;
  final int missionXp;
  final int adjustmentXp;
  final List<Mission> missions;

  @override
  Widget build(BuildContext context) {
    final completed = missions.where((m) => m.status == MissionStatus.approved).length;
    final pending = missions.where((m) => m.status == MissionStatus.submitted).length;
    final active = missions.where((m) => m.status == MissionStatus.available).length;
    final medal = xp >= 60 ? 'GOLD' : xp >= 50 ? 'SILVER' : xp >= 40 ? 'BRONZE' : 'STARTER';

    return Scaffold(
      backgroundColor: _canvas,
      appBar: AppBar(
        backgroundColor: _canvas,
        foregroundColor: _ink,
        elevation: 0,
        title: const Text('My Profile', style: TextStyle(fontWeight: FontWeight.w900)),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
          children: [
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFF292044), Color(0xFF5B45B4)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                borderRadius: BorderRadius.circular(26),
              ),
              child: Column(children: [
                Container(width: 76, height: 76, decoration: BoxDecoration(color: Colors.white.withOpacity(.13), shape: BoxShape.circle, border: Border.all(color: Colors.white24, width: 1.5)), child: const Icon(Icons.person_rounded, color: Colors.white, size: 42)),
                const SizedBox(height: 13),
                const Text('MIS SUMAIYA', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: .8)),
                const SizedBox(height: 4),
                const Text('Your learning journey, your achievements.', textAlign: TextAlign.center, style: TextStyle(color: Color(0xFFD8D2F5), fontSize: 12)),
                const SizedBox(height: 18),
                Text('$xp XP', style: const TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w900)),
                Text('$medal LEVEL', style: const TextStyle(color: Color(0xFFFFD37D), fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
              ]),
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: const Color(0xFF211F32), borderRadius: BorderRadius.circular(17), border: Border.all(color: const Color(0xFF343149))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('XP BREAKDOWN', style: TextStyle(color: _muted, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1.3)),
                const SizedBox(height: 12),
                _xpLine('Approved mission rewards', missionXp, const Color(0xFF58C99A)),
                const SizedBox(height: 8),
                _xpLine('Admin adjustments', adjustmentXp, adjustmentXp < 0 ? const Color(0xFFFF8B8B) : const Color(0xFFFFD37D)),
                const Padding(padding: EdgeInsets.symmetric(vertical: 10), child: Divider(color: Color(0xFF343149), height: 1)),
                _xpLine('Current total', xp, _ink, bold: true),
              ]),
            ),
            const SizedBox(height: 22),
            const Text('YOUR PROGRESS', style: TextStyle(color: _muted, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
            const SizedBox(height: 11),
            Row(children: [
              Expanded(child: _stat('COMPLETED', '$completed', Icons.check_circle_rounded, const Color(0xFF3A9B72))),
              const SizedBox(width: 10),
              Expanded(child: _stat('IN REVIEW', '$pending', Icons.hourglass_top_rounded, const Color(0xFFC18B35))),
            ]),
            const SizedBox(height: 10),
            _stat('ACTIVE MISSIONS', '$active', Icons.flag_rounded, _purple),
            const SizedBox(height: 22),
            const _XpNotifications(),
            const SizedBox(height: 20),
            _TaskHistoryCalendar(missions: missions),
          ],
        ),
      ),
    );
  }
}

class _XpNotifications extends StatelessWidget {
  const _XpNotifications();

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return const SizedBox.shrink();
    final db = FirebaseFirestore.instance;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('XP NOTIFICATIONS', style: TextStyle(color: _muted, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
      const SizedBox(height: 10),
      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: db.collection('xp_adjustments').where('studentUid', isEqualTo: uid).snapshots(),
        builder: (context, adjustmentSnapshot) {
          if (adjustmentSnapshot.hasError) return const Text('Could not load XP notifications.', style: TextStyle(color: _muted, fontSize: 12));
          if (!adjustmentSnapshot.hasData) return const Center(child: Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator()));
          return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: db.collection('xp_earnings').where('studentUid', isEqualTo: uid).snapshots(),
            builder: (context, earningSnapshot) {
              if (earningSnapshot.hasError) return const Text('Could not load XP notifications.', style: TextStyle(color: _muted, fontSize: 12));
              if (!earningSnapshot.hasData) return const Center(child: Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator()));
              final items = <Map<String, dynamic>>[];
              for (final doc in adjustmentSnapshot.data!.docs) {
                final d = doc.data();
                items.add({...d, '_kind': 'adjustment'});
              }
              for (final doc in earningSnapshot.data!.docs) {
                final d = doc.data();
                items.add({...d, '_kind': 'earning'});
              }
              items.sort((a, b) {
                final at = a['createdAt']; final bt = b['createdAt'];
                final ad = at is Timestamp ? at.toDate() : DateTime.fromMillisecondsSinceEpoch(0);
                final bd = bt is Timestamp ? bt.toDate() : DateTime.fromMillisecondsSinceEpoch(0);
                return bd.compareTo(ad);
              });
              if (items.isEmpty) return Container(width: double.infinity, padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFF211F32), borderRadius: BorderRadius.circular(15)), child: const Text('No XP updates yet. Complete a mission to earn your first XP!', style: TextStyle(color: _muted, fontSize: 12)));
              final recentItems = items.take(20).toList();
              return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                if (items.length > 20)
                  Padding(padding: const EdgeInsets.only(bottom: 8), child: Text('Showing latest 20 of ${items.length} XP updates', style: const TextStyle(color: _muted, fontSize: 10))),
                ...recentItems.map((data) {
                final isEarning = data['_kind'] == 'earning';
                final delta = isEarning ? ((data['xp'] as num?)?.toInt() ?? 0) : ((data['xpDelta'] as num?)?.toInt() ?? 0);
                final reason = (data['reason'] as String?) ?? (data['message'] as String?) ?? '';
                final missionTitle = data['missionTitle'] as String? ?? 'Mission completed';
                final stamp = data['createdAt'];
                final date = stamp is Timestamp ? stamp.toDate() : null;
                final positive = delta >= 0;
                final heading = isEarning ? missionTitle : '${positive ? 'XP added' : 'XP deducted'}';
                return Container(margin: const EdgeInsets.only(bottom: 9), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFF211F32), borderRadius: BorderRadius.circular(15), border: Border.all(color: const Color(0xFF343149))), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(isEarning ? Icons.emoji_events_rounded : (positive ? Icons.add_circle_rounded : Icons.remove_circle_rounded), color: positive ? const Color(0xFF58C99A) : const Color(0xFFFF8B8B)), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(heading, style: const TextStyle(color: _ink, fontWeight: FontWeight.w800, fontSize: 13)), const SizedBox(height: 3), Text('${positive ? '+' : ''}$delta XP', style: TextStyle(color: positive ? const Color(0xFF58C99A) : const Color(0xFFFF8B8B), fontWeight: FontWeight.w900, fontSize: 15)), if (reason.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text(reason, style: const TextStyle(color: _ink, fontSize: 12))), if (date != null) Padding(padding: const EdgeInsets.only(top: 5), child: Text('${date.day}/${date.month}/${date.year}  ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}', style: const TextStyle(color: _muted, fontSize: 10)))]))]));
              }),
              ]);
            },
          );
        },
      ),
    ]);
  }
}

class _TaskHistoryCalendar extends StatefulWidget {
  const _TaskHistoryCalendar({required this.missions});
  final List<Mission> missions;

  @override
  State<_TaskHistoryCalendar> createState() => _TaskHistoryCalendarState();
}

class _TaskHistoryCalendarState extends State<_TaskHistoryCalendar> {
  late DateTime _month;
  DateTime? _selected;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    _month = DateTime(now.year, now.month);
  }

  DateTime _oneMonthAgo(DateTime date) {
    final previousMonth = DateTime(date.year, date.month - 1, 1);
    final lastDay = DateTime(previousMonth.year, previousMonth.month + 1, 0).day;
    return DateTime(previousMonth.year, previousMonth.month,
        date.day > lastDay ? lastDay : date.day);
  }

  List<Mission> _forDay(DateTime day) {
    final now = DateTime.now();
    final cutoff = _oneMonthAgo(now);
    return widget.missions.where((m) {
      final date = m.createdAt ?? m.approvedAt ?? m.submittedAt;
      if (date == null || date.isBefore(cutoff) || date.isAfter(now)) return false;
      return date.year == day.year && date.month == day.month && date.day == day.day;
    }).toList();
  }

  void _showTasks(DateTime day) {
    final tasks = _forDay(day);
    if (tasks.isEmpty) return;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF211F32),
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (context) => SafeArea(child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${_weekday(day.weekday)}, ${day.day} ${_monthName(day.month)} ${day.year}', style: const TextStyle(color: _ink, fontSize: 16, fontWeight: FontWeight.w900)),
          const SizedBox(height: 12),
          ...tasks.map((m) => Container(
            width: double.infinity,
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: const Color(0xFF302B48), borderRadius: BorderRadius.circular(15), border: Border.all(color: const Color(0xFF484064))),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(m.title, style: const TextStyle(color: _ink, fontWeight: FontWeight.w900)),
              const SizedBox(height: 5),
              Text(m.description.isEmpty ? 'No additional description.' : m.description, style: const TextStyle(color: _muted, fontSize: 12, height: 1.45)),
              const SizedBox(height: 8),
              Wrap(spacing: 8, runSpacing: 6, crossAxisAlignment: WrapCrossAlignment.center, children: [
                _historyChip('${m.points} XP', const Color(0xFFB9A9FF)),
                _historyChip(_statusLabel(m.status), _statusColor(m.status)),
                _historyChip(m.category, const Color(0xFFB9A9FF)),
              ]),
              const SizedBox(height: 8),
              if (m.createdAt != null)
                Text('Created: ${_formatHistoryDate(m.createdAt!)}', style: const TextStyle(color: _muted, fontSize: 10)),
              if (m.submittedAt != null)
                Text('Submitted: ${_formatHistoryDate(m.submittedAt!)}', style: const TextStyle(color: _muted, fontSize: 10)),
              if (m.approvedAt != null)
                Text('Approved: ${_formatHistoryDate(m.approvedAt!)}', style: const TextStyle(color: _muted, fontSize: 10)),
            ]),
          )),
        ]),
      )),
    );
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final cutoff = _oneMonthAgo(now);
    final oldest = DateTime(cutoff.year, cutoff.month);
    final latest = DateTime(now.year, now.month);
    final firstWeekday = DateTime(_month.year, _month.month, 1).weekday;
    final daysInMonth = DateTime(_month.year, _month.month + 1, 0).day;
    final cells = ((firstWeekday - 1) + daysInMonth + 6) ~/ 7 * 7;
    final canGoBack = _month.isAfter(oldest) &&
        DateTime(_month.year, _month.month + 1, 0).isAfter(cutoff.subtract(const Duration(days: 1)));
    final canGoForward = _month.isBefore(latest);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: const Color(0xFF211F32), borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFF343149))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.calendar_month_rounded, color: _purple, size: 22),
          const SizedBox(width: 9),
          const Expanded(child: Text('Last 1 Month Task Calendar', style: TextStyle(color: _ink, fontWeight: FontWeight.w900))),
          IconButton(onPressed: canGoBack ? () => setState(() => _month = DateTime(_month.year, _month.month - 1)) : null, icon: const Icon(Icons.chevron_left_rounded), color: _ink, disabledColor: _muted),
          IconButton(onPressed: canGoForward ? () => setState(() => _month = DateTime(_month.year, _month.month + 1)) : null, icon: const Icon(Icons.chevron_right_rounded), color: _ink, disabledColor: _muted),
        ]),
        Center(child: Text('${_monthName(_month.month)} ${_month.year}', style: const TextStyle(color: _ink, fontWeight: FontWeight.w800, fontSize: 14))),
        const SizedBox(height: 13),
        Row(children: ['M','T','W','T','F','S','S'].map((d) => Expanded(child: Center(child: Text(d, style: const TextStyle(color: _muted, fontSize: 10, fontWeight: FontWeight.w800))))).toList()),
        const SizedBox(height: 8),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: cells,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 7, mainAxisSpacing: 5, crossAxisSpacing: 5),
          itemBuilder: (context, index) {
            final dayNumber = index - (firstWeekday - 1) + 1;
            if (dayNumber < 1 || dayNumber > daysInMonth) return const SizedBox.shrink();
            final day = DateTime(_month.year, _month.month, dayNumber);
            final tasks = _forDay(day);
            final hasTasks = tasks.isNotEmpty;
            final selected = _selected != null && _selected!.year == day.year && _selected!.month == day.month && _selected!.day == day.day;
            return InkWell(
              borderRadius: BorderRadius.circular(10),
              onTap: hasTasks ? () { setState(() => _selected = day); _showTasks(day); } : null,
              child: Container(
                decoration: BoxDecoration(color: selected ? _purple : hasTasks ? const Color(0xFF393052) : const Color(0xFF29263A), borderRadius: BorderRadius.circular(10), border: Border.all(color: hasTasks ? const Color(0xFF8068E8) : const Color(0xFF343149))),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text('$dayNumber', style: TextStyle(color: hasTasks || selected ? Colors.white : _muted, fontSize: 11, fontWeight: hasTasks ? FontWeight.w900 : FontWeight.w500)),
                  if (hasTasks) Container(margin: const EdgeInsets.only(top: 3), width: 4, height: 4, decoration: const BoxDecoration(color: Color(0xFFFFD37D), shape: BoxShape.circle)),
                ]),
              ),
            );
          },
        ),
        const SizedBox(height: 10),
        const Text('Dates within the last one month are shown. Tap a highlighted date to view task details.', style: TextStyle(color: _muted, fontSize: 10, height: 1.4)),
      ]),
    );
  }
}

String _monthName(int month) => const [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
][month - 1];

String _weekday(int weekday) => const [
  'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'
][weekday - 1];

Widget _xpLine(String label, int value, Color color, {bool bold = false}) => Row(children: [
  Expanded(child: Text(label, style: TextStyle(color: bold ? _ink : _muted, fontSize: 12, fontWeight: bold ? FontWeight.w900 : FontWeight.w600))),
  Text('${value > 0 ? '+' : ''}$value XP', style: TextStyle(color: color, fontSize: bold ? 15 : 13, fontWeight: FontWeight.w900)),
]);

Widget _stat(String label, String value, IconData icon, Color color) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: const Color(0xFF211F32), borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFF343149))),
    child: Row(children: [
      Container(width: 36, height: 36, decoration: BoxDecoration(color: color.withOpacity(.15), borderRadius: BorderRadius.circular(11)), child: Icon(icon, color: color, size: 19)),
      const SizedBox(width: 11),
      Expanded(child: Text(label, style: const TextStyle(color: _muted, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: .3))),
      Text(value, style: const TextStyle(color: _ink, fontSize: 22, fontWeight: FontWeight.w900)),
    ]),
  );


String _statusLabel(MissionStatus status) {
  switch (status) {
    case MissionStatus.available: return 'ACTIVE';
    case MissionStatus.submitted: return 'IN REVIEW';
    case MissionStatus.approved: return 'COMPLETED';
  }
}

Color _statusColor(MissionStatus status) {
  switch (status) {
    case MissionStatus.available: return const Color(0xFFB9A9FF);
    case MissionStatus.submitted: return const Color(0xFFFFD37D);
    case MissionStatus.approved: return const Color(0xFF58C99A);
  }
}

Widget _historyChip(String label, Color color) => Container(
  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
  decoration: BoxDecoration(color: color.withOpacity(.12), borderRadius: BorderRadius.circular(20), border: Border.all(color: color.withOpacity(.35))),
  child: Text(label, style: TextStyle(color: color, fontSize: 9, fontWeight: FontWeight.w900)),
);

String _formatHistoryDate(DateTime date) => '${date.day}/${date.month}/${date.year} ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
