import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'login_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'screens/app_shell.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MomoTaskApp());
}

class MomoTaskApp extends StatefulWidget {
  const MomoTaskApp({super.key});

  @override
  State<MomoTaskApp> createState() => _MomoTaskAppState();
}

class _MomoTaskAppState extends State<MomoTaskApp> {
  late final Future<FirebaseApp> firebaseInit;

  @override
  void initState() {
    super.initState();
    firebaseInit = Firebase.initializeApp();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MOMOTASK',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF7658F5)),
      scaffoldBackgroundColor: const Color(0xFFF6F5FB),
      useMaterial3: true,
      inputDecorationTheme: InputDecorationTheme(border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)), filled: true, fillColor: const Color(0xFFF8F7FC)),
      ),
      home: FutureBuilder<FirebaseApp>(
        future: firebaseInit,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Scaffold(
              body: Center(
                child: CircularProgressIndicator(),
              ),
            );
          }

          if (snapshot.hasError) {
            return Scaffold(
              body: Center(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: SelectableText(
                    'Firebase Error:\n${snapshot.error}',
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            );
          }

          return const AuthGate();
        },
      ),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  Future<Widget> _destination(User user) async {
    final doc = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
    if (!doc.exists) {
      await FirebaseAuth.instance.signOut();
      return const LoginScreen();
    }
    final role = doc.data()?['role'];
    if (role != 'admin' && role != 'student') {
      await FirebaseAuth.instance.signOut();
      return const LoginScreen();
    }
    return AppShell(role: role as String);
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, auth) {
        if (auth.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        final user = auth.data;
        if (user == null) return const LoginScreen();
        return FutureBuilder<Widget>(
          future: _destination(user),
          builder: (context, profile) {
            if (profile.connectionState == ConnectionState.waiting) {
              return const Scaffold(body: Center(child: CircularProgressIndicator()));
            }
            if (profile.hasError) {
              return Scaffold(body: Center(child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text('Could not load account profile. Please check your internet connection and try again.\n\n${profile.error}', textAlign: TextAlign.center),
              )));
            }
            return profile.data ?? const LoginScreen();
          },
        );
      },
    );
  }
}
