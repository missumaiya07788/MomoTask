import '../models/mission.dart';

final demoMissions = <Mission>[
  Mission(
    id: 'm1',
    title: 'Focus for 45 minutes',
    description: 'Choose one subject and study without distractions.',
    points: 20,
    category: 'Focus',
    dueLabel: 'Today',
  ),
  Mission(
    id: 'm2',
    title: 'Solve 20 MCQs',
    description: 'Practice questions from any current science topic.',
    points: 15,
    category: 'Practice',
    dueLabel: 'Today',
  ),
  Mission(
    id: 'm3',
    title: 'Revise one topic',
    description: 'Review your notes and write down 3 key ideas.',
    points: 10,
    category: 'Revision',
    dueLabel: 'Tomorrow',
  ),
];
