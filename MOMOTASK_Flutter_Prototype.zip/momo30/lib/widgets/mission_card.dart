import 'package:flutter/material.dart';
import '../models/mission.dart';

class MissionCard extends StatelessWidget {
  const MissionCard({super.key, required this.mission, required this.adminMode, this.onSubmit});
  final Mission mission;
  final bool adminMode;
  final VoidCallback? onSubmit;

  @override
  Widget build(BuildContext context) {
    final cardBg = adminMode ? const Color(0xFF211F32) : const Color(0xFF211F32);
    final cardLine = const Color(0xFF343149);
    final primaryText = const Color(0xFFF5F2FF);
    final secondaryText = const Color(0xFFA7A2BD);
    final statusText = switch (mission.status) {
      MissionStatus.available => 'READY TO START',
      MissionStatus.submitted => 'WAITING FOR APPROVAL',
      MissionStatus.approved => 'COMPLETED',
    };
    final statusColor = switch (mission.status) {
      MissionStatus.available => const Color(0xFF7658F5),
      MissionStatus.submitted => const Color(0xFFC18B35),
      MissionStatus.approved => const Color(0xFF3A9B72),
    };
    final iconBg = switch (mission.status) {
      MissionStatus.available => const Color(0xFF342C55),
      MissionStatus.submitted => const Color(0xFF45351F),
      MissionStatus.approved => const Color(0xFF203D34),
    };
    Future<void> showFullTask() async {
      await showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * .90),
        builder: (sheetContext) => Container(
          padding: const EdgeInsets.fromLTRB(22, 12, 22, 26),
          decoration: BoxDecoration(color: adminMode ? const Color(0xFF211F32) : const Color(0xFF211F32), borderRadius: const BorderRadius.vertical(top: Radius.circular(28)), border: const Border(top: BorderSide(color: Color(0xFF343149)))),
          child: SafeArea(child: Column(children: [
            Expanded(child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: Container(width: 42, height: 4, decoration: BoxDecoration(color: const Color(0xFF514B68), borderRadius: BorderRadius.circular(8)))),
            const SizedBox(height: 12),
            Row(children: [
              const Expanded(child: Text('MISSION DETAILS', style: TextStyle(color: Color(0xFFAA98FF), fontSize: 10, letterSpacing: 1.5, fontWeight: FontWeight.w900))),
              IconButton(
                tooltip: 'Close task details',
                onPressed: () => Navigator.pop(sheetContext),
                icon: const Icon(Icons.close_rounded, color: Color(0xFFE7E2F7)),
                style: IconButton.styleFrom(backgroundColor: const Color(0xFF342C55), minimumSize: const Size(38, 38), padding: EdgeInsets.zero),
              ),
            ]),
            const SizedBox(height: 8),
            Row(children: [const Icon(Icons.menu_book_rounded, color: Color(0xFF7658F5)), const SizedBox(width: 8), const Text('YOUR TASK', style: TextStyle(color: Color(0xFF7658F5), fontSize: 10, letterSpacing: 1.4, fontWeight: FontWeight.w900)), const Spacer(), Text('+${mission.points} XP', style: const TextStyle(color: Color(0xFF7658F5), fontWeight: FontWeight.w900))]),
            const SizedBox(height: 14),
            Text(mission.title, style: const TextStyle(color: Color(0xFFF5F2FF), fontSize: 22, height: 1.25, fontWeight: FontWeight.w900)),
            const SizedBox(height: 10),
            Wrap(spacing: 8, runSpacing: 8, children: [
              _detailChip(mission.category, Icons.category_outlined),
              _detailChip(mission.dueLabel, Icons.calendar_today_rounded),
              _detailChip(statusText, Icons.flag_outlined),
            ]),
            const SizedBox(height: 20),
            const Text('TASK INSTRUCTIONS', style: TextStyle(color: Color(0xFFA7A2BD), fontSize: 10, letterSpacing: 1.2, fontWeight: FontWeight.w900)),
            const SizedBox(height: 9),
            Container(width: double.infinity, padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: const Color(0xFF2B2741), borderRadius: BorderRadius.circular(17), border: Border.all(color: const Color(0xFF40395B))), child: SelectableText(mission.description.isEmpty ? 'No additional instructions.' : mission.description, style: const TextStyle(color: Color(0xFFF0ECFA), fontSize: 14, height: 1.75))),
            const SizedBox(height: 20),
          ]))),
            if (!adminMode && mission.status == MissionStatus.available) Padding(
              padding: const EdgeInsets.only(top: 12),
              child: SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () { Navigator.pop(sheetContext); onSubmit?.call(); }, icon: const Icon(Icons.check_circle_outline_rounded), label: const Text('Submit task'), style: FilledButton.styleFrom(backgroundColor: const Color(0xFF7658F5), foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 15), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)))))),
          ])),
        ),
      );
    }
    return LayoutBuilder(builder: (context, constraints) {
      final compact = constraints.maxWidth < 340;
      final titleBlock = Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(mission.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: primaryText, fontWeight: FontWeight.w800, fontSize: 14, height: 1.25)),
        const SizedBox(height: 3),
        Text('${mission.category}  ·  ${mission.dueLabel}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFF89879B), fontSize: 10)),
      ]));
      final xpBadge = Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6), decoration: BoxDecoration(color: const Color(0xFF342C55), border: Border.all(color: const Color(0xFF514477)), borderRadius: BorderRadius.circular(30)), child: Text('+${mission.points} XP', style: const TextStyle(color: Color(0xFFC8BCFF), fontSize: 10, fontWeight: FontWeight.w900)));
      return Semantics(
        button: true,
        label: 'Open full task details for ${mission.title}',
        child: GestureDetector(
        onTap: showFullTask,
        child: Container(
        decoration: BoxDecoration(color: cardBg, borderRadius: BorderRadius.circular(19), border: Border.all(color: cardLine), boxShadow: [BoxShadow(color: const Color(0xFF7658F5).withOpacity(.08), blurRadius: 12, offset: const Offset(0, 4))]),
        child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Container(width: 43, height: 43, decoration: BoxDecoration(color: iconBg, borderRadius: BorderRadius.circular(14)), child: Icon(Icons.auto_awesome_rounded, color: statusColor, size: 21)), const SizedBox(width: 11), titleBlock, if (!compact) ...[const SizedBox(width: 6), xpBadge]]),
          if (compact) Padding(padding: const EdgeInsets.only(left: 54, top: 8), child: xpBadge),
          if (mission.description.isNotEmpty) ...[const SizedBox(height: 11), Text(mission.description, maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFFA7A2BD), fontSize: 12, height: 1.4))],
          const SizedBox(height: 10),
          Row(mainAxisSize: MainAxisSize.min, children: const [Icon(Icons.open_in_full_rounded, size: 12, color: Color(0xFFAA98FF)), SizedBox(width: 5), Text('TAP TO VIEW FULL TASK', style: TextStyle(color: Color(0xFFAA98FF), fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: .65))]),
          const SizedBox(height: 12),
          Wrap(alignment: WrapAlignment.spaceBetween, crossAxisAlignment: WrapCrossAlignment.center, runSpacing: 9, spacing: 10, children: [
            Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6), decoration: BoxDecoration(color: iconBg, borderRadius: BorderRadius.circular(30)), child: Row(mainAxisSize: MainAxisSize.min, children: [Container(width: 6, height: 6, decoration: BoxDecoration(color: statusColor, shape: BoxShape.circle)), const SizedBox(width: 6), Text(statusText, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: statusColor, fontWeight: FontWeight.w800, fontSize: 9, letterSpacing: .35))])),
            if (!adminMode && mission.status == MissionStatus.available) FilledButton(onPressed: onSubmit, style: FilledButton.styleFrom(backgroundColor: const Color(0xFF7658F5), foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9), visualDensity: VisualDensity.compact, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: const Text('Submit task', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800))),
          ]),
        ])),
      )));
    });
  }

  static Widget _detailChip(String label, IconData icon) => Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7), decoration: BoxDecoration(color: const Color(0xFF342C55), borderRadius: BorderRadius.circular(30)), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 12, color: Color(0xFFAA98FF)), const SizedBox(width: 5), Text(label, style: const TextStyle(color: Color(0xFFE7E2F7), fontSize: 10, fontWeight: FontWeight.w800))]));
}
