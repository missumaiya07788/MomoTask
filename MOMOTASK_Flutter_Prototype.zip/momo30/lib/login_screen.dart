import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'screens/app_shell.dart';

const _loginInk = Color(0xFF19162F);
const _loginMuted = Color(0xFF89869D);
const _loginPurple = Color(0xFF7658F5);

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  bool isLoading = false;
  bool obscurePassword = true;

  Future<void> login() async {
    final email = emailController.text.trim();
    final password = passwordController.text.trim();
    if (email.isEmpty || password.isEmpty) {
      showMessage('Please enter email and password.');
      return;
    }
    setState(() => isLoading = true);
    try {
      final credential = await FirebaseAuth.instance.signInWithEmailAndPassword(email: email, password: password);
      final uid = credential.user!.uid;
      final userDoc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
      if (!userDoc.exists) {
        await FirebaseAuth.instance.signOut();
        throw Exception('User profile not found.');
      }
      final role = userDoc.data()?['role'];
      if (role != 'admin' && role != 'student') {
        await FirebaseAuth.instance.signOut();
        throw Exception('Invalid user role.');
      }
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => AppShell(role: role)));
    } on FirebaseAuthException catch (e) {
      showMessage(e.message ?? 'Login failed.');
    } catch (e) {
      showMessage(e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  void showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(behavior: SnackBarBehavior.floating, content: Text(message)));
  }

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  InputDecoration _fieldDecoration(String label, IconData icon, {Widget? suffix}) => InputDecoration(
    labelText: label,
    labelStyle: const TextStyle(color: _loginMuted, fontSize: 13),
    prefixIcon: Icon(icon, color: _loginMuted, size: 20),
    suffixIcon: suffix,
    filled: true,
    fillColor: const Color(0xFFF8F7FC),
    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 17),
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Color(0xFFECEAF3))),
    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: _loginPurple, width: 1.5)),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F3FB),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 28),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 430),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(24, 28, 24, 30),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF211C3B), Color(0xFF654BC8)]),
                      borderRadius: BorderRadius.circular(30),
                      boxShadow: [BoxShadow(color: _loginPurple.withOpacity(.22), blurRadius: 28, offset: const Offset(0, 14))],
                    ),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Container(width: 58, height: 58, decoration: BoxDecoration(color: Colors.white.withOpacity(.13), borderRadius: BorderRadius.circular(19), border: Border.all(color: Colors.white.withOpacity(.16))), child: const Center(child: Text('🐱', style: TextStyle(fontSize: 31)))),
                      const SizedBox(height: 23),
                      const Text('MOMOTASK', style: TextStyle(color: Colors.white, fontSize: 27, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
                      const SizedBox(height: 7),
                      const Text('A little focus. A little fun. A lovely reward.', style: TextStyle(color: Color(0xFFDCD5FF), fontSize: 12, height: 1.5)),
                      const SizedBox(height: 23),
                      Row(children: [
                        _welcomeTag(Icons.auto_awesome_rounded, 'STUDY'),
                        const SizedBox(width: 8),
                        _welcomeTag(Icons.emoji_events_rounded, 'EARN XP'),
                        const SizedBox(width: 8),
                        _welcomeTag(Icons.favorite_rounded, 'REWARD'),
                      ]),
                    ]),
                  ),
                  const SizedBox(height: 22),
                  Container(
                    padding: const EdgeInsets.all(22),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(26), border: Border.all(color: const Color(0xFFECEAF3)), boxShadow: [BoxShadow(color: _loginInk.withOpacity(.035), blurRadius: 20, offset: const Offset(0, 8))]),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('Welcome back', style: TextStyle(color: _loginInk, fontSize: 21, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 5),
                      const Text('Sign in to continue your MOMOTASK journey.', style: TextStyle(color: _loginMuted, fontSize: 12, height: 1.5)),
                      const SizedBox(height: 22),
                      TextField(controller: emailController, keyboardType: TextInputType.emailAddress, textInputAction: TextInputAction.next, decoration: _fieldDecoration('Email address', Icons.mail_outline_rounded)),
                      const SizedBox(height: 13),
                      TextField(controller: passwordController, obscureText: obscurePassword, onSubmitted: (_) => isLoading ? null : login(), decoration: _fieldDecoration('Password', Icons.lock_outline_rounded, suffix: IconButton(tooltip: obscurePassword ? 'Show password' : 'Hide password', icon: Icon(obscurePassword ? Icons.visibility_off_outlined : Icons.visibility_outlined, color: _loginMuted, size: 20), onPressed: () => setState(() => obscurePassword = !obscurePassword)))),
                      const SizedBox(height: 20),
                      SizedBox(width: double.infinity, height: 54, child: FilledButton(
                        onPressed: isLoading ? null : login,
                        style: FilledButton.styleFrom(backgroundColor: _loginPurple, foregroundColor: Colors.white, disabledBackgroundColor: _loginPurple.withOpacity(.55), elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                        child: isLoading ? const SizedBox(width: 21, height: 21, child: CircularProgressIndicator(strokeWidth: 2.2, color: Colors.white)) : const Row(mainAxisAlignment: MainAxisAlignment.center, children: [Text('Sign in', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800)), SizedBox(width: 9), Icon(Icons.arrow_forward_rounded, size: 19)]),
                      )),
                    ]),
                  ),
                  const SizedBox(height: 17),
                  const Center(child: Text('MADE FOR LITTLE DAILY WINS', style: TextStyle(color: _loginMuted, fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 1.4))),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  static Widget _welcomeTag(IconData icon, String label) => Expanded(child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8), decoration: BoxDecoration(color: Colors.white.withOpacity(.11), borderRadius: BorderRadius.circular(11)), child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, color: const Color(0xFFFFD37D), size: 12), const SizedBox(width: 5), Flexible(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: .35)))])));
}
