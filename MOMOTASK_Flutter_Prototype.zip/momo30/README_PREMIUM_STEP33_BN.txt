MOMOTASK PREMIUM UI — STEP 33

এই ধাপে XP Adjustment-এর চলমান অনুরোধের জন্য একটি in-flight guard যোগ করা হয়েছে।

পরিবর্তন:
1. Admin XP adjustment চলার সময় দ্বিতীয় concurrent adjustment call প্রত্যাখ্যান হবে।
2. Firestore transaction সফল বা ব্যর্থ—দুই ক্ষেত্রেই finally block guard reset করবে।
3. আগের transaction-based balance calculation, ০-এর নিচে XP না নামানোর client-side check, operationId এবং immutable adjustment ledger বহাল আছে।

গুরুত্বপূর্ণ সীমাবদ্ধতা:
- এটি একই AppShell instance-এর concurrent call আটকায়; অ্যাপ বন্ধ/পুনরায় খোলা, network retry-এর বাইরে আলাদা করে Confirm, বা অন্য client থেকে duplicate request ঠেকানোর server-side idempotency নয়।
- XP balance validation এখনো client-side Firestore transaction-এ; Cloud Function/server-side validation যোগ করা হয়নি।
- Firestore Rules-এ এই পরিবর্তনের জন্য কোনো পরিবর্তন দরকার নেই।
- Flutter SDK এখানে নেই; flutter analyze/build এবং APK পরীক্ষা করা হয়নি।

পরবর্তী নিরাপত্তা ধাপের জন্য Firebase Cloud Functions deploy করতে হবে এবং client থেকে callable function ব্যবহার করতে হবে।
