MOMOTASK Student APK — Step45

এই ধাপে ব্যবহারকারীর নির্দিষ্ট করা তিনটি পরিবর্তন করা হয়েছে:

1. Student APK Launcher Icon
- MOMOTASK-এর purple theme-এর সঙ্গে matching cat/study themed launcher icon তৈরি করা হয়েছে।
- icon resource শুধু student flavor-এর জন্য তৈরি করা হয়েছে; Admin flavor-এর resource পরিবর্তন করা হয়নি।
- GitHub Actions-এ Android project generate হওয়ার পর এবং APK build-এর আগে `bash scripts/apply_student_launcher_icon.sh` চালাতে হবে।

2. Student Profile Calendar
- Task History Calendar-কে MIS SUMAIYA / XP profile card-এর ঠিক নিচে আনা হয়েছে।
- Calendar বর্তমান মাস থেকে শুরু হয় এবং মাস/বছর বদলালে স্বয়ংক্রিয়ভাবে নতুন মাসে যায়।
- Calendar-এর বিদ্যমান date navigation ও task details অক্ষুণ্ণ রাখা হয়েছে।

3. Student Dashboard Rewards and Weekly Activity
- Study Power reward milestones: 100 XP Savoy Discone Ice Cream; 150 XP 1 Plate of Momos; 200 XP 1 Plate of Momos + Mountain Dew; 250 XP Half Plate Kacchi; 300 XP Burger; 350 XP Pizza.
- Current XP অনুযায়ী next reward, remaining XP এবং milestone progress দেখানো হয়।
- Weekly Activity বর্তমান Monday–Sunday week এবং প্রতিদিনের date number দেখায়।
- কোনো দিনে approved mission না থাকলে সেই দিনের bar ফাঁকা থাকে; approved mission থাকলে bar পূরণ হয়।
- Filled bar-এ tap করলে ওই দিনে approved হওয়া mission-এর নাম ও XP দেখা যায়।

পরীক্ষার সীমাবদ্ধতা:
- Source code ও assets ZIP-এ যুক্ত করা হয়েছে এবং archive integrity পরীক্ষা করা হয়েছে।
- এই environment-এ Flutter/Dart SDK নেই; তাই flutter analyze, Android APK build বা device runtime test করা যায়নি।
- Launcher icon সম্পূর্ণভাবে APK-তে প্রয়োগ করতে GitHub Actions workflow-এ উপরে উল্লেখিত script command চালাতে হবে।
