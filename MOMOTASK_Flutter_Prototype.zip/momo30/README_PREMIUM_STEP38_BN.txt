MOMOTASK Premium UI — Step38

এই ধাপে Student Dashboard-এর Weekly Activity অংশে ছোট কিন্তু ব্যবহারিক উন্নতি করা হয়েছে।

পরিবর্তন:
1. Weekly Activity-তে বর্তমান সপ্তাহের তারিখের পরিসর দেখাবে (যেমন 2 Nov – 8 Nov)।
2. সপ্তাহের দিনের সংক্ষিপ্ত নামের মধ্যে আজকের দিনটি আলাদা রঙে Highlight হবে।
3. XP bar ও approved mission-এর হিসাব আগের মতোই Firestore-এর বাস্তব xp_earnings data থেকে আসবে।
4. Locked Premium UI-এর সামগ্রিক রং ও layout অপরিবর্তিত রাখা হয়েছে।

পরীক্ষা:
ZIP integrity check করা হয়েছে। Flutter/Dart SDK না থাকায় flutter analyze/build বা APK runtime test করা হয়নি।
