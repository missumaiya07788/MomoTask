#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ANDROID_APP="$ROOT/android/app"
STUDENT_RES="$ANDROID_APP/src/student/res"

if [[ ! -d "$ANDROID_APP" ]]; then
  echo "ERROR: Android project not found at $ANDROID_APP. Run flutter create before applying the Student icon." >&2
  exit 1
fi

mkdir -p "$STUDENT_RES/mipmap-mdpi" \
         "$STUDENT_RES/mipmap-hdpi" \
         "$STUDENT_RES/mipmap-xhdpi" \
         "$STUDENT_RES/mipmap-xxhdpi" \
         "$STUDENT_RES/mipmap-xxxhdpi" \
         "$STUDENT_RES/mipmap-anydpi-v26" \
         "$STUDENT_RES/drawable" \
         "$STUDENT_RES/values"

for density in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
  cp "$ROOT/assets/icon/generated/$density/ic_launcher.png" \
     "$STUDENT_RES/mipmap-$density/ic_launcher.png"
done
cp "$ROOT/assets/icon/generated/ic_launcher_foreground.png" \
   "$STUDENT_RES/drawable/ic_launcher_foreground.png"

cat > "$STUDENT_RES/mipmap-anydpi-v26/ic_launcher.xml" <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/momotask_student_icon_background" />
    <foreground android:drawable="@drawable/ic_launcher_foreground" />
</adaptive-icon>
XML

cat > "$STUDENT_RES/values/ic_launcher_background.xml" <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="momotask_student_icon_background">#392477</color>
</resources>
XML

echo "Student launcher icon applied. Admin launcher resources were not changed."
