MOMOTASK Premium UI - Step44

এই ধাপে Student Profile-এর XP Notifications অংশকে দীর্ঘ History-তে আরও ব্যবহারবান্ধব করা হয়েছে।

- XP Notification-গুলো সর্বশেষ তারিখ অনুযায়ী সাজানো থাকবে।
- Profile-এ সর্বশেষ ২০টি XP update দেখানো হবে, যাতে দীর্ঘ History পুরো Profile-কে অতিরিক্ত বড় না করে।
- ২০টির বেশি update থাকলে মোট সংখ্যা-সহ 'Showing latest 20' বার্তা দেখাবে।
- XP update না থাকলে নতুন Mission সম্পন্ন করে প্রথম XP অর্জনের উৎসাহমূলক বার্তা দেখাবে।
- Mission XP ও Admin Adjustment—দুই ধরনের Notification-ই আগের মতো থাকবে।
- Premium UI-এর মূল Design Language অপরিবর্তিত।

পরীক্ষার সীমাবদ্ধতা:
- ZIP archive integrity পরীক্ষা করা হয়েছে।
- এই পরিবেশে Flutter SDK না থাকায় flutter analyze, APK build বা runtime test করা হয়নি।
