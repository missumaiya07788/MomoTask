
STEP 26 — XP EARNINGS LEDGER

এই ধাপে Approved Mission XP আলাদা xp_earnings collection-এ স্থায়ী ledger হিসেবে লেখা হয়। Approval transaction-এর মধ্যে mission approve এবং deterministic missionId document তৈরি হয়, তাই একই mission বারবার approve করলে duplicate XP যোগ হয় না। মোট XP এখন xp_earnings-এর যোগফল + xp_adjustments-এর xpDelta যোগফল। Mission document পরে archive/delete হলেও ledger entry থাকলে অর্জিত XP থাকবে।

IMPORTANT FIRESTORE RULES ADDITION
বর্তমান Rules-এর xp_adjustments match-এর পরে এবং catch-all match-এর আগে এই অংশ যোগ করতে হবে:

match /xp_earnings/{earningId} {
  allow create: if isAdmin()
    && request.resource.data.keys().hasAll([
      'studentUid', 'missionId', 'xp', 'createdAt', 'createdBy'
    ])
    && request.resource.data.studentUid is string
    && request.resource.data.missionId is string
    && request.resource.data.xp is int
    && request.resource.data.xp >= 0
    && request.resource.data.createdBy == request.auth.uid;

  allow read: if isAdmin()
    || (isStudent() && resource.data.studentUid == request.auth.uid);

  allow update, delete: if false;
}

IMPORTANT: This ledger begins recording when this updated app is used. Already approved missions need a one-time backfill from existing mission documents before old missions are deleted. Missions already deleted before ledger creation cannot be reconstructed from Firestore unless their details are available in backups/export. Do not delete old mission records until backfill is completed.
