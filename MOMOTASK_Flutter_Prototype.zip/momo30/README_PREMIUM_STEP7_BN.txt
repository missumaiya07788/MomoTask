MOMOTASK Premium UI – Step 7

এই ধাপে Mission Card ও Admin review card-এর dark premium visual consistency উন্নত করা হয়েছে:
- Available / Waiting / Completed status chip-এ dark tinted background ও readable status color.
- XP badge-এ dark purple surface এবং subtle border.
- Mission card-এর full-details tap target-এ semantic button label যোগ করা হয়েছে (accessibility).
- Admin review card-এর approval icon ও XP text dark theme-এ বেশি readable করা হয়েছে.

Firebase/Auth/Firestore data flow, Mission model, submission callback, approval callback এবং XP logic পরিবর্তন করা হয়নি।

Validation: ZIP integrity check করা হয়েছে। Flutter SDK এই environment-এ নেই, তাই dart analyze / flutter build চালানো হয়নি।
