MOMOTASK Premium UI — Step35 (Spark-compatible)

এই ধাপের উদ্দেশ্য: Firebase Spark Free Plan-এ থাকা অবস্থায় MOMOTASK-এর XP Add/Remove ব্যবস্থা সচল রাখা এবং অপ্রয়োজনীয় Cloud Functions dependency বাদ দেওয়া।

গুরুত্বপূর্ণ পরিবর্তন:
1. Step34-এর Cloud Functions dependency এবং deploy-নির্ভর XP call ব্যবহার করা হয়নি।
2. Step33-এর Firestore Transaction-ভিত্তিক XP Adjustment flow রাখা হয়েছে।
3. XP হিসাব: সব xp_earnings-এর XP + সব xp_adjustments-এর xpDelta।
4. XP ০-এর নিচে নামলে অ্যাপের transaction বাতিল হবে।
5. XP কমালে Reason বাধ্যতামূলক; বাড়ালে Message ঐচ্ছিক। খালি Message হলে reason হিসেবে খালি string সংরক্ষিত হয়।
6. Transaction retry হলে একই adjustment document reference ব্যবহৃত হয়।
7. একই AppShell-এ concurrent XP request আটকানোর in-progress lock রাখা হয়েছে।

সীমাবদ্ধতা:
- এটি Cloud Function নয়; Firebase Spark Plan-এ চলার জন্য client-side Firestore transaction ব্যবহার করে।
- একই কাজ নতুন করে Confirm করলে নতুন Adjustment তৈরি হতে পারে।
- আলাদা client/device-এর concurrent operation সম্পূর্ণ server-side lock দিয়ে নিয়ন্ত্রিত নয়।
- Rules-এ xp_adjustments ও xp_earnings immutable রাখা উচিত।

এই ধাপে UI redesign করা হয়নি; আগে লক করা Premium UI অপরিবর্তিত রাখার উদ্দেশ্য।

Build status: Flutter/Dart SDK এই পরিবেশে নেই; flutter analyze/build চালানো হয়নি। APK runtime test করা হয়নি।
