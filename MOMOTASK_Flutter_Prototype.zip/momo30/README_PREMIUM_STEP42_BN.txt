MOMOTASK Premium UI - Step42

এই ধাপে Admin Mission Approval-এর একটি validation উন্নত করা হয়েছে:
- কেবল Student-এর Submitted Mission-ই Admin Approve করতে পারবে।
- Available Mission সরাসরি Approve করার চেষ্টা হলে তা বাতিল হবে।
- Approved Mission দ্বিতীয়বার Approve করলে XP পুনরায় যোগ হবে না।
- একই deterministic xp_earnings document আগে থেকেই থাকলে নতুন earning record তৈরি হবে না।

গুরুত্বপূর্ণ:
- এটি Spark Plan-এ ব্যবহারের উপযোগী Firestore client transaction logic।
- Firestore Rules-এ Admin approval অনুমোদিত থাকতে হবে।
- ZIP তৈরি ও archive integrity যাচাই করা হয়েছে; Flutter SDK/build পরিবেশে compile বা APK runtime test করা হয়নি।
