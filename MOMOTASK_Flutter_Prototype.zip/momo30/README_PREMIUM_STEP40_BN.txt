MOMOTASK Premium UI - Step 40

এই ধাপে Student Mission Submission আরও নির্ভরযোগ্য করা হয়েছে।

পরিবর্তন:
1. Submit করার আগে Firestore Transaction দিয়ে Mission-এর বর্তমান অবস্থা পড়া হয়।
2. Mission আর available না থাকলে দ্বিতীয়বার Submit করা হয় না।
3. Mission মুছে গেলে পরিষ্কার error দেখানোর জন্য StateError ফেরত দেওয়া হয়।
4. একই সময়ে একাধিক Submit request এলে Firestore transaction conflict/retry-এর মাধ্যমে একটিমাত্র status transition কার্যকর রাখে।

আগের Premium UI, XP হিসাব, Calendar এবং Weekly Activity অপরিবর্তিত।

পরীক্ষা: ZIP integrity check করা হয়েছে। Flutter SDK না থাকায় flutter analyze/build বা বাস্তব Firebase APK test করা হয়নি।
