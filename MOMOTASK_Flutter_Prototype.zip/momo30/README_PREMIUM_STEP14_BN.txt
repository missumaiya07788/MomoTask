MOMOTASK Premium UI – Step 14

Student Dashboard-এর Weekly Activity chart-এর visual polish:
- প্রতিদিনের bar-এর জন্য subtle dark track যোগ করা হয়েছে।
- XP থাকা দিনের bar proportional height-এ দেখা যায়; ছোট মানও দৃশ্যমান থাকে।
- Purple gradient ও soft shadow দিয়ে chart-কে Dashboard-এর premium theme-এর সঙ্গে মিলানো হয়েছে।
- শূন্য XP দিনের জন্য ছোট baseline রাখা হয়েছে।

শুধু presentation code পরিবর্তন করা হয়েছে। Firebase, Mission data, approval, submission বা XP calculation পরিবর্তন করা হয়নি।

যাচাই: ZIP integrity পরীক্ষা করা হয়েছে। Flutter SDK না থাকায় flutter analyze/build চালানো হয়নি।
