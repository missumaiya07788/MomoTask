MOMOTASK Premium UI — Step39

এই ধাপে Student Dashboard-এর Weekly Activity অংশে সপ্তাহের কত দিন Approved Mission থেকে পড়াশোনার achievement হয়েছে তা দেখানো হয়েছে। হিসাবটি Firestore-এর xp_earnings থেকে পাওয়া weeklyTasks ডেটা দিয়ে হয়; কোনো demo বা অনুমানভিত্তিক সংখ্যা নয়।

- ৭ দিনের মধ্যে কয়দিন approved mission হয়েছে তা দেখাবে।
- ধারাবাহিকতা উৎসাহিত করতে ছোট status message দেখাবে।
- XP, mission count, Firebase data flow এবং locked Premium UI অপরিবর্তিত।

নোট: এটি approved mission achievement-এর day count, সম্পূর্ণ study streak নয়। শুধু পড়াশোনা করলেই যদি mission approve না হয়, সে দিন এখানে গণনা হবে না।

ZIP integrity check করা হয়েছে। Flutter SDK/build environment না থাকায় flutter analyze, APK build বা device runtime test করা হয়নি।
