import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'login_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MomoTaskApp());
}

class MomoTaskApp extends StatefulWidget {
  const MomoTaskApp({super.key});

  @override
  State<MomoTaskApp> createState() => _MomoTaskAppState();
}

class _MomoTaskAppState extends State<MomoTaskApp> {
  late final Future<FirebaseApp> firebaseInit;

  @override
  void initState() {
    super.initState();
    firebaseInit = Firebase.initializeApp();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MOMOTASK',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFE58EAD),
        ),
      ),
      home: FutureBuilder<FirebaseApp>(
        future: firebaseInit,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Scaffold(
              body: Center(
                child: CircularProgressIndicator(),
              ),
            );
          }

          if (snapshot.hasError) {
            return Scaffold(
              body: Center(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: SelectableText(
                    'Firebase Error:\n${snapshot.error}',
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            );
          }

          return const LoginScreen();
        },
      ),
    );
  }
}