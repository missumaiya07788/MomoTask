import 'package:flutter/material.dart';
import '../models/mission.dart';
import '../widgets/mission_card.dart';

const _ink = Color(0xFF30243F);
const _purple = Color(0xFF7652A5);
const _pink = Color(0xFFE9A4C0);
const _gold = Color(0xFFE8C77A);

class AdminScreen extends StatelessWidget {
  const AdminScreen({super.key, required this.missions, required this.onAddMission, required this.onApprove, required this.onLogout});
  final List<Mission> missions;
  final ValueChanged<Mission> onAddMission;
  final ValueChanged<Mission> onApprove;
  final VoidCallback onLogout;

  static const templates = <String>[
    'Minimal Aesthetic', 'Modern Luxe', 'Robotic / Sci-fi', 'Money Heist-inspired',
    'Dark Mystery-inspired', 'If Wishes Could Kill-inspired', 'Munawar · Dhandho Comedy-inspired',
    'Messi · Football Legend', 'Momo Reward', 'Kacchi Reward', 'Burger & Pizza',
    'Ice Cream Treat', 'Mountain Adventure',
  ];

  Future<void> _createMission(BuildContext context) async {
    final title = TextEditingController();
    final details = TextEditingController();
    final points = TextEditingController(text: '10');
    String mode = 'Minimal text';
    String template = templates.first;
    final formKey = GlobalKey<FormState>();

    final result = await showDialog<bool>(context: context, builder: (dialogContext) => StatefulBuilder(
      builder: (context, setDialogState) => AlertDialog(
        title: const Text('Create a mission ✨'),
        content: SizedBox(width: 420, child: Form(key: formKey, child: SingleChildScrollView(child: Column(
          mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Choose how your mission should look', style: TextStyle(color: _ink, fontWeight: FontWeight.w600)),
            const SizedBox(height: 10),
            Wrap(spacing: 8, children: [
              ChoiceChip(label: const Text('Simple text'), selected: mode == 'Minimal text', onSelected: (_) => setDialogState(() => mode = 'Minimal text')),
              ChoiceChip(label: const Text('Use a template'), selected: mode == 'Template', onSelected: (_) => setDialogState(() => mode = 'Template')),
            ]),
            if (mode == 'Template') ...[
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(value: template, isExpanded: true, decoration: const InputDecoration(labelText: 'Design collection'),
                items: templates.map((t) => DropdownMenuItem(value: t, child: Text(t, overflow: TextOverflow.ellipsis))).toList(),
                onChanged: (v) { if (v != null) setDialogState(() => template = v); }),
            ],
            const SizedBox(height: 12),
            TextFormField(controller: title, decoration: const InputDecoration(labelText: 'Mission title *'), validator: (v) => (v == null || v.trim().isEmpty) ? 'Add a title' : null),
            TextFormField(controller: details, decoration: const InputDecoration(labelText: 'Instructions'), maxLines: 3),
            TextFormField(controller: points, decoration: const InputDecoration(labelText: 'XP points'), keyboardType: TextInputType.number,
              validator: (v) { final n = int.tryParse(v ?? ''); return n == null || n < 0 ? 'Enter a valid XP amount' : null; }),
          ],
        )))),
        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancel')),
          FilledButton(onPressed: () { if (formKey.currentState!.validate()) Navigator.pop(dialogContext, true); }, child: const Text('Create mission'))],
      ),
    ));
    if (result == true) {
      onAddMission(Mission(id: DateTime.now().microsecondsSinceEpoch.toString(), title: title.text.trim(),
        description: details.text.trim().isEmpty ? 'Complete this study mission.' : details.text.trim(),
        points: int.parse(points.text), category: mode == 'Template' ? template : 'Simple text', dueLabel: 'Today'));
    }
    title.dispose(); details.dispose(); points.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pending = missions.where((m) => m.status == MissionStatus.submitted).toList();
    return SafeArea(child: Container(color: const Color(0xFFF8F5FB), child: ListView(padding: const EdgeInsets.fromLTRB(18, 16, 18, 28), children: [
      Row(children: [Container(width: 48, height: 48, decoration: BoxDecoration(color: const Color(0xFFEDE3F7), borderRadius: BorderRadius.circular(16)), child: const Center(child: Text('🥟', style: TextStyle(fontSize: 27))),),
        const SizedBox(width: 11), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('MOMOTASK', style: TextStyle(color: _ink, fontSize: 21, fontWeight: FontWeight.w900, letterSpacing: 1)), Text('ADMIN CONTROL CENTER', style: TextStyle(color: _purple, fontSize: 10, letterSpacing: 1.5, fontWeight: FontWeight.bold))])),
        IconButton(onPressed: onLogout, tooltip: 'Logout', icon: const Icon(Icons.logout_rounded, color: _ink))]),
      const SizedBox(height: 20),
      Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(gradient: const LinearGradient(colors: [_ink, Color(0xFF654A83)]), borderRadius: BorderRadius.circular(24)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Your study world, your rules ✨', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 7), const Text('Create little missions. Celebrate every step.', style: TextStyle(color: Color(0xFFE9DFF1))), const SizedBox(height: 18),
          Row(children: [_stat('MISSIONS', '${missions.length}', _pink), const SizedBox(width: 10), _stat('TO REVIEW', '${pending.length}', _gold)])])),
      const SizedBox(height: 20),
      SizedBox(height: 52, child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: _purple, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
        onPressed: () => _createMission(context), icon: const Icon(Icons.add_rounded), label: const Text('Create New Mission', style: TextStyle(fontWeight: FontWeight.bold)))),
      const SizedBox(height: 22),
      const Text('MISSION TEMPLATE LIBRARY', style: TextStyle(color: _ink, fontSize: 13, fontWeight: FontWeight.w900, letterSpacing: 1.1)),
      const SizedBox(height: 10),
      _templatePreview(context, 'Minimal & Modern', 'Clean layouts, calm colors', Icons.auto_awesome, const Color(0xFFECE5F5)),
      _templatePreview(context, 'Robotic & Sci-fi', 'Futuristic mission styles', Icons.smart_toy_outlined, const Color(0xFFDDECF2)),
      _templatePreview(context, 'Munawar · Dhandho Comedy', 'Stage-inspired fan collection', Icons.mic_none_rounded, const Color(0xFFFFE9D8)),
      _templatePreview(context, 'Lionel Messi · Football Legend', 'Football-inspired collection', Icons.sports_soccer_rounded, const Color(0xFFDCEDE8)),
      _templatePreview(context, 'Movies, Series & Food Rewards', 'Mystery, momo, kacchi, pizza and more', Icons.movie_creation_outlined, const Color(0xFFF8E3EB)),
      const SizedBox(height: 20),
      const Text('MISSION BOARD', style: TextStyle(color: _ink, fontSize: 13, fontWeight: FontWeight.w900, letterSpacing: 1.1)),
      const SizedBox(height: 10),
      if (missions.isEmpty) const _EmptyNote(text: 'No missions yet. Create one with a design template or choose simple text.'),
      ...missions.map((m) => MissionCard(mission: m, adminMode: true)),
      const SizedBox(height: 16),
      const Text('NEEDS YOUR APPROVAL', style: TextStyle(color: _ink, fontSize: 13, fontWeight: FontWeight.w900, letterSpacing: 1.1)),
      const SizedBox(height: 10),
      if (pending.isEmpty) const _EmptyNote(text: 'Student submissions will appear here for your review.'),
      ...pending.map((m) => Card(child: ListTile(leading: const CircleAvatar(backgroundColor: Color(0xFFEDE3F7), child: Icon(Icons.task_alt, color: _purple)), title: Text(m.title), subtitle: Text('${m.points} XP · Submitted by Sumaiya'), trailing: FilledButton(onPressed: () => onApprove(m), child: const Text('Approve'))))),
      const SizedBox(height: 12), const _EmptyNote(text: 'Prototype mode: mission changes currently stay on this device. Online mission sync is a separate development step.'),
    ])));
  }

  Widget _stat(String label, String value, Color accent) => Expanded(child: Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.white.withValues(alpha: .12), borderRadius: BorderRadius.circular(15)), child: Row(children: [Container(width: 4, height: 30, decoration: BoxDecoration(color: accent, borderRadius: BorderRadius.circular(4))), const SizedBox(width: 9), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(value, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)), Text(label, style: const TextStyle(color: Colors.white70, fontSize: 9, letterSpacing: .8))]))])));

  Widget _templatePreview(BuildContext context, String title, String subtitle, IconData icon, Color color) => Container(margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)), child: Row(children: [Container(width: 42, height: 42, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(13)), child: Icon(icon, color: _ink)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: _ink, fontWeight: FontWeight.bold)), Text(subtitle, style: const TextStyle(color: Colors.black54, fontSize: 11))])), const Icon(Icons.chevron_right_rounded, color: _purple)]));
}

class _EmptyNote extends StatelessWidget {
  const _EmptyNote({required this.text}); final String text;
  @override Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFFEFE9F5), borderRadius: BorderRadius.circular(15)), child: Text(text, style: const TextStyle(color: Color(0xFF665775))));
}
