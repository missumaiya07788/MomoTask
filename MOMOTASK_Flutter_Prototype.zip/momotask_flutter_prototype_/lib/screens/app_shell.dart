import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/mission.dart';
import 'admin_screen.dart';
import 'student_screen.dart';

class AppShell extends StatefulWidget {
  final String role;

  const AppShell({
    super.key,
    required this.role,
  });

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  final List<Mission> missions = [];
  int xp = 0;

  void addMission(Mission mission) {
    setState(() {
      missions.insert(0, mission);
    });
  }

  void submitMission(Mission mission) {
    setState(() {
      mission.status = MissionStatus.submitted;
    });
  }

  void approveMission(Mission mission) {
    setState(() {
      mission.status = MissionStatus.approved;
      xp += mission.points;
    });
  }

  Future<void> _logout(BuildContext context) async {
    await FirebaseAuth.instance.signOut();
    if (context.mounted) {
      Navigator.of(context).popUntil((route) => route.isFirst);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.role == 'admin') {
      return AdminScreen(
        missions: missions,
        onAddMission: addMission,
        onApprove: approveMission,
        onLogout: () => _logout(context),
      );
    }

    return StudentScreen(
      missions: missions,
      xp: xp,
      onSubmit: submitMission,
      onSwitchRole: () {},
      onLogout: () => _logout(context),
    );
  }
}