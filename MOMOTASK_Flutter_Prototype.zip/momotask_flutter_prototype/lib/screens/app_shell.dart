import 'package:flutter/material.dart';
import '../data/demo_data.dart';
import '../models/mission.dart';
import 'admin_screen.dart';
import 'student_screen.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  bool isAdmin = true;
  final missions = demoMissions;
  int xp = 45;

  void addMission(Mission mission) {
    setState(() => missions.insert(0, mission));
  }

  void submitMission(Mission mission) {
    setState(() => mission.status = MissionStatus.submitted);
  }

  void approveMission(Mission mission) {
    setState(() {
      mission.status = MissionStatus.approved;
      xp += mission.points;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: isAdmin
          ? AdminScreen(
              missions: missions,
              onAddMission: addMission,
              onApprove: approveMission,
              onSwitchRole: () => setState(() => isAdmin = false),
            )
          : StudentScreen(
              missions: missions,
              xp: xp,
              onSubmit: submitMission,
              onSwitchRole: () => setState(() => isAdmin = true),
            ),
    );
  }
}
