import 'package:flutter/material.dart';
import 'screens/app_shell.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // Firebase will be initialized after the project's Firebase config is added.
  runApp(const MomoTaskApp());
}

class MomoTaskApp extends StatelessWidget {
  const MomoTaskApp({super.key});

  @override
  Widget build(BuildContext context) {
    const pink = Color(0xFFE58EAD);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MOMOTASK',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: pink,
          brightness: Brightness.light,
          surface: const Color(0xFFFFF9FB),
        ),
        scaffoldBackgroundColor: const Color(0xFFFFF7FA),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFFFFF7FA),
          foregroundColor: Color(0xFF49343D),
          elevation: 0,
          centerTitle: false,
        ),
        cardTheme: CardTheme(
          color: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(22),
            side: const BorderSide(color: Color(0xFFF5E5EB)),
          ),
        ),
      ),
      home: const AppShell(),
    );
  }
}
